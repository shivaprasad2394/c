package com.example.ble_voice_test;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.example.ble_voice_test.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;


/*
 * Android BLE Voice App - SDK 26 (Oreo)
 * Core functionality with BLE GATT server and advertising logic
 */

public class MainActivity extends AppCompatActivity {

    private TextView statusText;
    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeAdvertiser advertiser;
    private BluetoothGattServer gattServer;
    private BluetoothDevice subscribedDevice;
    private BluetoothGattCharacteristic voiceCharacteristic;
    private boolean clientSubscribed = false;
    private static final UUID VOICE_SERVICE_UUID = UUID.fromString("12345678-1234-5678-1234-56789abcdef0");
    private static final UUID VOICE_CHAR_UUID = UUID.fromString("12345678-1234-5678-1234-56789abcdef1");
    private static final UUID CLIENT_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private byte[] recordedAudio;
    private byte[] encodedAudio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        Button btnRecord = findViewById(R.id.btnRecord);
        Button btnEncrypt = findViewById(R.id.btnEncrypt);
        Button btnStartAdvertise = findViewById(R.id.btnStartAdvertise);
        Button btnSendVoice = findViewById(R.id.btnSendVoice);

        requestPermissions();

        btnRecord.setOnClickListener(v -> startRecording());
        btnEncrypt.setOnClickListener(v -> encodeAudio());
        btnStartAdvertise.setOnClickListener(v -> startBleAdvertising());
        btnSendVoice.setOnClickListener(v -> sendVoiceNotification());
    }

    private void requestPermissions() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.RECORD_AUDIO);
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE);
        } else {
            permissions.add(Manifest.permission.BLUETOOTH);
            permissions.add(Manifest.permission.BLUETOOTH_ADMIN);
        }

        ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), 1);
    }

// Updated startBleAdvertising() with Bluetooth enable prompt and safe onActivityResult handling
private static final int REQUEST_ENABLE_BT = 1001;
    private boolean pendingStartAdvertising = false;
    private void startBleAdvertising() {
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();
        Log.i("ble_voice_test", "startBleAdvertising() triggered");

        if (bluetoothAdapter == null) {
            statusText.setText("Bluetooth not supported on this device.");
            Log.e("ble_voice_test", "Bluetooth not supported");
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Log.w("ble_voice_test", "Bluetooth is disabled. Prompting user to enable it.");
            pendingStartAdvertising = true;
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            return;
        }

        if (!bluetoothAdapter.isMultipleAdvertisementSupported()) {
            statusText.setText("BLE Advertising not supported");
            Log.i("ble_voice_test", "adv not supported");
            return;
        }

        Log.i("ble_voice_test", "adv begin");
        advertiser = bluetoothAdapter.getBluetoothLeAdvertiser();

        AdvertiseSettings settings = new AdvertiseSettings.Builder()
                .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
                .setConnectable(true)
                .build();

        // Adjusted data to fit 31-byte limit
        AdvertiseData advertiseData = new AdvertiseData.Builder()
                .setIncludeDeviceName(false) // Keep false to prevent ADVERTISE_FAILED_DATA_TOO_LARGE
                .addServiceUuid(new ParcelUuid(VOICE_SERVICE_UUID))
                .build();

        AdvertiseData scanResponse = new AdvertiseData.Builder()
                .setIncludeDeviceName(true) // Add device name in scan response instead
                .build();

        Log.i("ble_voice_test", "Advertise UUID: " + VOICE_SERVICE_UUID);
        Log.i("ble_voice_test", "Device Name (adapter): " + bluetoothAdapter.getName());

        advertiser.startAdvertising(settings, advertiseData, scanResponse, advertiseCallback);
        setupGattServer();
        statusText.setText("BLE Advertising started...");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                Log.i("ble_voice_test", "Bluetooth enabled by user");
                if (pendingStartAdvertising) {
                    pendingStartAdvertising = false;
                    startBleAdvertising();
                }
            } else {
                Log.w("ble_voice_test", "User denied enabling Bluetooth");
                statusText.setText("Bluetooth must be enabled to start advertising.");
            }
        }
    }

    private final AdvertiseCallback advertiseCallback = new AdvertiseCallback() {
        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.i("BLE", "Advertising started successfully");
        }

        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.e("BLE", "Advertising failed: " + errorCode);
            statusText.setText("Advertise failed");
        }
    };

    private void setupGattServer() {
        gattServer = bluetoothManager.openGattServer(this, gattServerCallback);

        BluetoothGattService service = new BluetoothGattService(
                VOICE_SERVICE_UUID,
                BluetoothGattService.SERVICE_TYPE_PRIMARY);

        voiceCharacteristic = new BluetoothGattCharacteristic(
                VOICE_CHAR_UUID,
                BluetoothGattCharacteristic.PROPERTY_NOTIFY,
                BluetoothGattCharacteristic.PERMISSION_READ);

        BluetoothGattDescriptor descriptor = new BluetoothGattDescriptor(
                CLIENT_CONFIG_UUID,
                BluetoothGattDescriptor.PERMISSION_READ | BluetoothGattDescriptor.PERMISSION_WRITE);
        voiceCharacteristic.addDescriptor(descriptor);

        service.addCharacteristic(voiceCharacteristic);
        gattServer.addService(service);
    }

    private final BluetoothGattServerCallback gattServerCallback = new BluetoothGattServerCallback() {
        @Override
        public void onConnectionStateChange(BluetoothDevice device, int status, int newState) {
            super.onConnectionStateChange(device, status, newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i("BLE", "Client connected: " + device.getAddress());
                runOnUiThread(() -> statusText.setText("Client connected: " + device.getAddress()));
            }else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.i("BLE", "Client disconnected: " + device.getAddress());
                runOnUiThread(() -> statusText.setText("Client disconnected: " + device.getAddress()));
            }
        }
        @Override
        public void onNotificationSent(BluetoothDevice device, int status) {
            Log.i("BLE", "Notification sent to " + device.getAddress() + ", status: " + status);
            runOnUiThread(() -> statusText.setText("Notification sent to: " + device.getAddress() + ", status: " + status));
        }
        @Override
        public void onDescriptorWriteRequest(BluetoothDevice device, int requestId, BluetoothGattDescriptor descriptor,
                                             boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {
            if (CLIENT_CONFIG_UUID.equals(descriptor.getUuid())) {
                if (Arrays.equals(value, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)) {
                    clientSubscribed = true;
                    subscribedDevice = device;
                    Log.i("BLE", "Client subscribed to notifications");
                    runOnUiThread(() -> statusText.setText("Client subscribed to notifications"));
                } else if (Arrays.equals(value, BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE)) {
                    clientSubscribed = false;
                    subscribedDevice = null;
                    Log.i("BLE", "Client unsubscribed");
                    runOnUiThread(() -> statusText.setText("Client unsubscribed from notifications"));
                }
                if (responseNeeded) {
                    gattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null);
                }
            }
        }
    };

    private void startRecording() {
        statusText.setText("Recording started...");
        // TODO: Implement audio recording and save to recordedAudio[]
    }

    private void encodeAudio() {
        statusText.setText("Encoding audio...");
        // TODO: Implement SBC encoding logic and save to encodedAudio[]
    }

    private void sendVoiceNotification() {
        if (clientSubscribed && encodedAudio != null && subscribedDevice != null) {
            int packetSize = 20;
            for (int i = 0; i < encodedAudio.length; i += packetSize) {
                int end = Math.min(i + packetSize, encodedAudio.length);
                byte[] chunk = Arrays.copyOfRange(encodedAudio, i, end);
                voiceCharacteristic.setValue(chunk);
                gattServer.notifyCharacteristicChanged(subscribedDevice, voiceCharacteristic, false);
            }
            statusText.setText("Voice data sent");
        } else {
            statusText.setText("Client not subscribed or data missing");
        }
    }
}
