#include <string.h>
#include <stdio.h>

#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_bt.h"
#include "esp_wifi.h"
#include "esp_nimble_hci.h"  /* For VHCI init in controller-only mode */
#include "esp_mac.h"
/* FIX: Correct header for WiFi internal buffer free (esp_private/wifi.h, not esp_wifi_private.h) */
#include "esp_private/wifi.h"

/* NimBLE Host headers */
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_gap.h"
#include "host/ble_gatt.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
#include "host/ble_hs_id.h"  // Add this at the top with other NimBLE includes

static const char *TAG = "BLE_WIFI_COEX";

/* BLE Configuration */
static const char *ble_target = "b4b7edc6";
static uint16_t ble_conn_handle = BLE_HS_CONN_HANDLE_NONE;
static uint8_t ble_paired = 0;

/* WiFi Configuration */
static const char *wifi_ssid = "G8X";
static uint8_t target_bssid[6] = {0};
//forward
static void ble_app_scan(void);

/* ============================================================================
 * BLE GAP Event Callback - Improved connect with retry
 * ============================================================================ */
static int ble_gap_event_cb(struct ble_gap_event *event, void *arg)
{
    struct ble_gap_conn_desc desc;
    int rc;

    switch (event->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (event->connect.status == 0) {
            ble_conn_handle = event->connect.conn_handle;
            rc = ble_gap_conn_find(ble_conn_handle, &desc);
            if (rc == 0) {
                ESP_LOGI(TAG, "BLE CONNECTED! Handle: %d", ble_conn_handle);
            }
            ESP_LOGI(TAG, "Initiating Just Works pairing...");
            rc = ble_gap_security_initiate(ble_conn_handle);
            if (rc != 0) {
                ESP_LOGE(TAG, "Security initiate failed: %d", rc);
            }
        } else {
            ESP_LOGE(TAG, "BLE Connection failed: %d", event->connect.status);
            ble_conn_handle = BLE_HS_CONN_HANDLE_NONE;
            vTaskDelay(pdMS_TO_TICKS(2000));
            ble_app_scan();  // Restart scan on failure
        }
        return 0;

    case BLE_GAP_EVENT_DISCONNECT:
        ESP_LOGI(TAG, "BLE DISCONNECTED (reason: %d)", event->disconnect.reason);
        ble_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        ble_paired = 0;
        vTaskDelay(pdMS_TO_TICKS(1000));
        ble_app_scan();
        return 0;

    case BLE_GAP_EVENT_DISC:
        if (event->disc.length_data > 0) {
            const uint8_t *adv_data = event->disc.data;
            uint16_t adv_len = event->disc.length_data;
            
            for (int i = 0; i < adv_len - 1; ) {
                uint8_t len = adv_data[i];
                uint8_t type = adv_data[i + 1];
                
                if (type == 0x09 || type == 0x08) {
                    char name[32] = {0};
                    int name_len = (len - 1 > 31) ? 31 : len - 1;
                    memcpy(name, &adv_data[i + 2], name_len);
                    
                    if (strncmp(name, ble_target, strlen(ble_target)) == 0) {
                        ESP_LOGI(TAG, "Target found: %s (RSSI: %d)", name, event->disc.rssi);
						uint8_t id_addr[6];
						int is_nrpa;
						rc = ble_hs_id_copy_addr(BLE_ADDR_RANDOM, id_addr, &is_nrpa);
						if (rc == BLE_HS_ENOADDR) {
							ESP_LOGE(TAG, "No random identity address available!");
							return 0;
						}                        
                        ble_gap_disc_cancel();
						struct ble_gap_conn_params conn_params = {
							.scan_itvl = 0x0040,
							.scan_window = 0x0030,
							.itvl_min = 0x0018,
							.itvl_max = 0x0028,
							.latency = 0,
							.supervision_timeout = 0x0300,  // ~7.5s
							.min_ce_len = 0x0010,
							.max_ce_len = 0x0300,
						};
						// Pass &conn_params to ble_gap_connect() instead of NULL                        
						rc = ble_gap_connect(BLE_OWN_ADDR_RANDOM,
                                            &event->disc.addr,
                                            30000,  // 30s timeout
                                            &conn_params,   // Default params - fixes EMSGSIZE
                                            ble_gap_event_cb,
                                            NULL);
                        if (rc == 0) {
                            ESP_LOGI(TAG, "Connection initiated");
                        } else {
                            ESP_LOGE(TAG, "Connect failed: %d - retrying scan", rc);
                            vTaskDelay(pdMS_TO_TICKS(3000));
                            ble_app_scan();
                        }
                        return 0;
/*                        struct ble_gap_conn_params conn_params = {
                            .scan_itvl = 0x40,
                            .scan_window = 0x30,
                            .itvl_min = 0x18,
                            .itvl_max = 0x48,    // Slightly higher max
                            .latency = 0,
                            .supervision_timeout = 0x1F4,  // 5 seconds
                            .min_ce_len = 0x0010,
                            .max_ce_len = 0x0300,
                        };

                        rc = ble_gap_connect(BLE_OWN_ADDR_RANDOM,
                                            &event->disc.addr,
                                            30000,
                                            NULL,  // Default params - fixes EMSGSIZE
                                            ble_gap_event_cb,
                                            NULL);
                        if (rc == 0) {
                            ESP_LOGI(TAG, "Connection request sent");
                        } else {
                            ESP_LOGE(TAG, "Connect failed: %d - retrying scan", rc);
                            vTaskDelay(pdMS_TO_TICKS(2000));
                            ble_app_scan();
                        }
                        return 0;*/
                    }
                }
                i += len + 1;
            }
        }
        return 0;

    case BLE_GAP_EVENT_ENC_CHANGE:
        if (event->enc_change.status == 0 /*&& event->enc_change.encrypted*/) {//compilation error no encrypted member
            ESP_LOGI(TAG, "BLE PAIRING & ENCRYPTION SUCCESS!");
            ble_paired = 1;
        } else {
            ESP_LOGE(TAG, "Encryption failed: %d", event->enc_change.status);
        }
        return 0;

    default:
        return 0;
    }
}
/* ============================================================================
 * Start BLE scanning - Passive mode for better stability
 * ============================================================================ */
static void ble_app_scan(void)
{
    int rc;
    struct ble_gap_disc_params disc_params = {
        .itvl = 0x80,       // 80 ms
        .window = 0x40,     // 40 ms
        .limited = 0,
        .passive = 1,       // ACTIVE SCAN - fixes EMSGSIZE and busy state
        .filter_policy = 0,
    };
    
    rc = ble_gap_disc(BLE_OWN_ADDR_RANDOM, 0, &disc_params, ble_gap_event_cb, NULL);
    if (rc != 0) {
        ESP_LOGW(TAG, "BLE scan start failed (%d) - retrying in 5s", rc);
        vTaskDelay(pdMS_TO_TICKS(5000));
        ble_app_scan();
    } else {
        ESP_LOGI(TAG, "BLE Active Scanning started");
    }
}

/* ============================================================================
 * NimBLE Host Sync Callback
 * ============================================================================ */
static void ble_host_sync_cb(void)
{
    ESP_LOGI(TAG, "BLE Host & Controller synced!");
    ble_svc_gap_init();
    ble_svc_gatt_init();
	// NEW: Configure static random identity address
	uint8_t base_mac[6];
	esp_efuse_mac_get_default(base_mac);//esp_read_mac(base_mac, ESP_MAC_WIFI_SOFTAP);  // Or esp_efuse_mac_get_default(base_mac);
	uint8_t rnd_addr[6];
	memcpy(rnd_addr, base_mac, 6);
	rnd_addr[5] |= 0xC0;  // Make static random
	int rc = ble_hs_id_set_rnd(rnd_addr);
	if (rc != 0) {
		ESP_LOGE(TAG, "Failed to set random identity: %d", rc);
		return;
	}    
    ble_app_scan();
}

/* ============================================================================
 * WiFi RX Callback - Promiscuous mode (DO NOT FREE BUFFER - driver handles it)
 * ============================================================================ */
static void wifi_rx_cb(void *buf, wifi_promiscuous_pkt_type_t type)
{
    if (buf == NULL) return;

    wifi_promiscuous_pkt_t *pkt = (wifi_promiscuous_pkt_t *)buf;

    if (type != WIFI_PKT_MGMT) {
        return;  // Ignore non-mgmt
    }

    uint8_t *frame = pkt->payload;
    uint16_t len = pkt->rx_ctrl.sig_len;

    if (len < 24) {
        return;
    }

    uint8_t frame_type = frame[0] & 0xFC;

    /* Probe Response (0x50) */
    if (frame_type == 0x50) {
    	ESP_LOGI(TAG, "Probe Response received on ch %d, RSSI %d", pkt->rx_ctrl.channel, pkt->rx_ctrl.rssi);
        uint8_t *ie = frame + 36;

        while (ie < frame + len - 2) {
            uint8_t ie_type = ie[0];
            uint8_t ie_len = ie[1];

            if (ie_type == 0x00 && ie_len == strlen(wifi_ssid) &&
                memcmp(&ie[2], wifi_ssid, ie_len) == 0) {
                
                ESP_LOGI(TAG, "WiFi AP Found: %s (RSSI: %d, Ch: %d)",
                        wifi_ssid, pkt->rx_ctrl.rssi, pkt->rx_ctrl.channel);
                memcpy(target_bssid, frame + 10, 6);
                return;  // Driver will recycle buffer
            }
            ie += 2 + ie_len;
        }
    }

    /* Authentication Response (0xB0) */
    else if (frame_type == 0xB0 && len >= 30) {
        uint8_t *src_addr = frame + 10;
        if (memcmp(src_addr, target_bssid, 6) == 0) {
            uint16_t auth_status = frame[28] | (frame[29] << 8);
            uint16_t auth_seq = frame[26] | (frame[27] << 8);

            if (auth_seq == 2 && auth_status == 0) {
                ESP_LOGI(TAG, "WiFi AUTH SUCCESS!");
            } else {
                ESP_LOGE(TAG, "WiFi AUTH FAILED - Status: %d", auth_status);
            }
        }
    }

    /* NO FREE - driver recycles automatically */
}
/* ============================================================================
 * Send WiFi Auth Frame
 * ============================================================================ */
static void wifi_send_auth_frame(const uint8_t *bssid)
{
    uint8_t auth_frame[30] = {0};
    uint8_t our_mac[6];

    esp_wifi_get_mac(WIFI_IF_STA, our_mac);

    auth_frame[0] = 0xB0;  /* Frame Control: Authentication */
    auth_frame[1] = 0x00;
    auth_frame[2] = 0x00;  /* Duration */
    auth_frame[3] = 0x00;

    memcpy(&auth_frame[4], bssid, 6);   /* Addr1 */
    memcpy(&auth_frame[10], our_mac, 6); /* Addr2 */
    memcpy(&auth_frame[16], bssid, 6);   /* Addr3 */

    auth_frame[22] = 0x00;  /* Sequence Control */
    auth_frame[23] = 0x00;

    auth_frame[24] = 0x00;  /* Algorithm (Open) */
    auth_frame[25] = 0x00;
    auth_frame[26] = 0x01;  /* Sequence */
    auth_frame[27] = 0x00;
    auth_frame[28] = 0x00;  /* Status */
    auth_frame[29] = 0x00;

    int rc = esp_wifi_80211_tx(WIFI_IF_STA, auth_frame, 30, true);
    if (rc == 0) {
        ESP_LOGI(TAG, "WiFi Auth frame sent");
    } else {
        ESP_LOGE(TAG, "WiFi Auth TX failed: %d", rc);
    }
}

/* ============================================================================
 * Send WiFi Probe Request
 * ============================================================================ */
static void wifi_start_scan(void)
{
    uint8_t probe_frame[60] = {0};
    uint8_t our_mac[6];

    esp_wifi_get_mac(WIFI_IF_STA, our_mac);

    probe_frame[0] = 0x40;  /* Frame Control: Probe Request */
    probe_frame[1] = 0x00;
    probe_frame[2] = 0x00;  /* Duration */
    probe_frame[3] = 0x00;

    memset(&probe_frame[4], 0xFF, 6);     /* Addr1 (Broadcast) */
    memcpy(&probe_frame[10], our_mac, 6); /* Addr2 */
    memset(&probe_frame[16], 0xFF, 6);    /* Addr3 (Broadcast) */

    probe_frame[22] = 0x00;  /* Sequence Control */
    probe_frame[23] = 0x00;

    /* SSID IE */
    probe_frame[24] = 0x00;
    probe_frame[25] = strlen(wifi_ssid);
    memcpy(&probe_frame[26], wifi_ssid, strlen(wifi_ssid));

    uint16_t frame_len = 26 + strlen(wifi_ssid);

    int rc = esp_wifi_80211_tx(WIFI_IF_STA, probe_frame, frame_len, false);
    if (rc == 0) {
        ESP_LOGI(TAG, "WiFi Probe Request sent");
    } else {
        ESP_LOGE(TAG, "WiFi Probe TX failed: %d", rc);
    }
}

/* ============================================================================
 * NimBLE Host Task
 * ============================================================================ */
static void nimble_host_task(void *param)
{
    ESP_LOGI(TAG, "NimBLE Host task started");
    nimble_port_run();
    vTaskDelete(NULL);
}

/* ============================================================================
 * Main Application
 * ============================================================================ */
void app_main(void)
{
    ESP_LOGI(TAG, "=== BLE + WiFi Coexistence Minimal ===");
    ESP_LOGI(TAG, "Target BLE Device: %s", ble_target);
    ESP_LOGI(TAG, "Target WiFi AP: %s", wifi_ssid);

    /* ====================================================================
     * CRITICAL: Initialize NVS FIRST (for RF calibration data)
     * ==================================================================== */
    ESP_LOGI(TAG, "Initializing NVS...");
    int rc = nvs_flash_init();
    if (rc == ESP_ERR_NVS_NO_FREE_PAGES || rc == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS needs erasing, proceeding...");
        nvs_flash_erase();
        rc = nvs_flash_init();
    }
    if (rc != 0) {
        ESP_LOGE(TAG, "NVS init failed: %d", rc);
        return;
    }
    ESP_LOGI(TAG, "NVS initialized");

    ESP_LOGI(TAG, "WiFi/BLE coexistence: AUTOMATIC");

    /* ====================================================================
     * BLE Initialization - Integrated for ESP-IDF v5+ (NimBLE handles controller)
     * ==================================================================== */
    ESP_LOGI(TAG, "Initializing NimBLE (host + controller integrated)...");

    rc = nimble_port_init();
    if (rc != 0) {
        ESP_LOGE(TAG, "nimble_port_init failed: %d", rc);
        return;
    }

    /* Configure sync callback (runs when host & controller synced) */
    ble_hs_cfg.sync_cb = ble_host_sync_cb;

    /* Just Works pairing */
    ble_hs_cfg.sm_io_cap = BLE_HS_IO_NO_INPUT_OUTPUT;
	ble_hs_cfg.sm_sc = 1;          // Enable Secure Connections
	ble_hs_cfg.sm_bonding = 1;     // Persist keys (optional)
	ble_hs_cfg.sm_mitm = 0;        // No MITM for Just Works
	ble_hs_cfg.sm_our_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
	ble_hs_cfg.sm_their_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    /* Optional: Reduce RAM usage */
    // ble_hs_cfg.max_hci_bufs = 10;
    // ble_hs_cfg.max_client_acl_bufs = 5;

    /* Start NimBLE host task */
    nimble_port_freertos_init(nimble_host_task);

    ESP_LOGI(TAG, "NimBLE initialized (controller integrated)");

	//ESP_LOGI(TAG, "Identity address: %02X:%02X:%02X:%02X:%02X:%02X", PRINT_MAC(rnd_addr));
    /* Initialize WiFi*/
    ESP_LOGI(TAG, "Initializing WiFi...");
    wifi_init_config_t wifi_cfg = WIFI_INIT_CONFIG_DEFAULT();
    wifi_cfg.nvs_enable = false;

    rc = esp_wifi_init(&wifi_cfg);
    if (rc != 0) {
        ESP_LOGE(TAG, "WiFi init failed: %d", rc);
        return;
    }

    rc = esp_wifi_set_mode(WIFI_MODE_STA);
    if (rc != 0) {
        ESP_LOGE(TAG, "WiFi set mode failed: %d", rc);
        return;
    }

    rc = esp_wifi_start();
    if (rc != 0) {
        ESP_LOGE(TAG, "WiFi start failed: %d", rc);
        return;
    }

    // Enable promiscuous mode 
    rc = esp_wifi_set_promiscuous(true);
    if (rc != 0) {
        ESP_LOGE(TAG, "WiFi promiscuous enable failed: %d", rc);
        return;
    }

    rc = esp_wifi_set_promiscuous_rx_cb(wifi_rx_cb);
    if (rc != 0) {
        ESP_LOGE(TAG, "WiFi RX callback set failed: %d", rc);
        return;
    }

    ESP_LOGI(TAG, "WiFi initialized");

    // Start Operations 
    ESP_LOGI(TAG, "Starting BLE + WiFi operations...");
    vTaskDelay(pdMS_TO_TICKS(500));
    wifi_start_scan();

    /* Main loop */
    int scan_counter = 0;
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(5000));
        scan_counter++;

        /* Periodic WiFi probe 
        if (scan_counter % 2 == 0) {
            //wifi_start_scan();
        }

        // Try WiFi auth if AP found 
        if (target_bssid[0] != 0) {
            wifi_send_auth_frame(target_bssid);
        }*/

        /* Restart BLE scan if disconnected */
        if (ble_conn_handle == BLE_HS_CONN_HANDLE_NONE && scan_counter % 4 == 0) {
            ble_app_scan();
        }

        /* Log status */
        if (ble_conn_handle != BLE_HS_CONN_HANDLE_NONE) {
            if (ble_paired) {
                ESP_LOGI(TAG, "Status: BLE Connected & Encrypted");
            } else {
                ESP_LOGI(TAG, "Status: BLE Connected (pairing...)");
            }
        } else {
            ESP_LOGI(TAG, "Status: BLE Scanning...");
        }
    }
}
