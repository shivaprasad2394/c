// smp_crypto.h

#ifndef SMP_CRYPTO_H
#define SMP_CRYPTO_H

#include <stdint.h>
#include <stdbool.h>
#include "mbedtls/aes.h"
#include "mbedtls/cipher.h"
#include "mbedtls/cmac.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/ecdh.h"
#include "mbedtls/ecp.h"
#include "mbedtls/version.h"

typedef struct {
    uint8_t x[32]; // P-256 x coordinate
    uint8_t y[32]; // P-256 y coordinate
} ble_sm_ecc_point_t;

typedef struct {
    uint8_t data[32];
} ble_sm_ecc_secret_t;
int ble_sm_alg_c1(
    const uint8_t *tk,        // Temporary Key
    const uint8_t *rand,      // Our random
    const uint8_t *preq,      // Pairing request (7 bytes)
    const uint8_t *pres,      // Pairing response (7 bytes)
    uint8_t iat,              // Initiator address type
    uint8_t rat,              // Responder address type
    const uint8_t *ia,        // Initiator address (6 bytes)
    const uint8_t *ra,        // Responder address (6 bytes)
    uint8_t *out_confirm      // 16 bytes out
);

// Prototype for ble_sm_alg_aes_cmac from smp_crypto_alg.c
int ble_sm_alg_aes_cmac(const uint8_t *key, const uint8_t *in, size_t len, uint8_t *out);

// Generate ephemeral ECDH keypair
int smp_crypto_gen_keypair(ble_sm_ecc_point_t *out_pub, ble_sm_ecc_secret_t *out_priv);

// Compute DHKey from peer public key and our private key
int smp_crypto_gen_dhkey(const ble_sm_ecc_point_t *peer_pub,
                         const ble_sm_ecc_secret_t *our_priv,
                         uint8_t *out_dhkey); // 32 bytes

// Compute Pairing Confirm
int smp_crypto_confirm(const uint8_t *tk,         // 16 bytes
                       const uint8_t *rand,       // 16 bytes (our random)
                       const uint8_t *peer_rand,  // 16 bytes (peer random)
                       const uint8_t *our_pub_x,  // 32 bytes
                       const uint8_t *peer_pub_x, // 32 bytes
                       uint8_t *out_confirm);     // 16 bytes

// Generate 16‑byte random
int smp_crypto_random(uint8_t *out_random);

// DHKey check helper (optional for now)
int smp_crypto_dhkey_check(const uint8_t *peer_rand,
                           const uint8_t *our_rand,
                           const uint8_t *dhkey,
                           const uint8_t *peer_confirm,
                           const uint8_t *our_pub_x,
                           const uint8_t *peer_pub_x);

int ble_sm_alg_c1(const uint8_t *tk, const uint8_t *r, const uint8_t *preq,
                  const uint8_t *pres, uint8_t iat, uint8_t rat,
                  const uint8_t *ia, const uint8_t *ra, uint8_t *out_confirm);
extern int ble_sm_alg_gen_dhkey(const uint8_t *peer_pub_key_x, const uint8_t *peer_pub_key_y, 
                                const uint8_t *our_priv_key, uint8_t *out_dhkey);
#endif

