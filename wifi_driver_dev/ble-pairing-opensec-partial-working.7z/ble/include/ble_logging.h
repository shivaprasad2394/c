#ifndef BLE_LOGGING_H
#define BLE_LOGGING_H

#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

// Log entry types (RENAMED to avoid macro conflicts)
// Log entry types (enum avoids preprocessor conflicts)
// ✅ Alternative: Keep type as uint8_t (simplest)
typedef enum {
    BLELOG_INIT = 0,
    BLELOG_SCAN = 1,
    BLELOG_CONNECT = 2,
    BLELOG_SMP = 3,
    BLELOG_ATT = 4,
    BLELOG_GATT = 5,
    BLELOG_KEEPALIVE = 6,
    BLELOG_ERROR = 7
} ble_log_type_e;

typedef struct {
    uint32_t timestamp;
    uint8_t type;      // ✅ Keep as uint8_t
    uint16_t handle;
    uint8_t opcode;
    uint32_t data1;
    uint32_t data2;
} blelogentry_t;


extern QueueHandle_t blelogqueue;

#define BLELOGISR(log_type_, log_handle_, log_opcode_, log_data1_, log_data2_) \
    do {                                                \
        if (blelogqueue != NULL) {                      \
            blelogentry_t entry;                        \
            entry.timestamp = xTaskGetTickCount();      \
            entry.type      = (uint8_t)(log_type_);     \
            entry.handle    = (uint16_t)(log_handle_);  \
            entry.opcode    = (uint8_t)(log_opcode_);   \
            entry.data1     = (uint32_t)(log_data1_);   \
            entry.data2     = (uint32_t)(log_data2_);   \
            BaseType_t xHigherPriorityTaskWoken = pdFALSE; \
            xQueueSendToBackFromISR(blelogqueue, &entry, \
                                    &xHigherPriorityTaskWoken); \
        }                                               \
    } while (0)


#endif

