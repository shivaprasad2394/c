/*
* BLE Central - Scan, Connect & Just Works Pairing (Direct HCI)
* Scans for "b4b7edc6", connects, and performs Just Works pairing
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "nvs_flash.h"
#include "esp_err.h"
#include "custom_ble.h"
#include "smp_crypto.h"
#include "ble_logging.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"


#define TARGET_DEVICE_NAME "b4b7edc6"

/* ========== HCI OpCodes & Events ========== */
#define HCI_PACKET_TYPE_CMD 0x01
#define HCI_PACKET_TYPE_EVT 0x04
#define HCI_EVT_CMD_COMPLETE 0x0E
#define HCI_EVT_CMD_STATUS 0x0F
#define HCI_EVT_LE_META 0x3E
#define HCI_LE_EVT_CONN_COMPLETE 0x01
#define HCI_LE_EVT_ADV_REPORT 0x02
#define HCI_LE_EVT_PASSKEY_DISPLAY 0x08
#define HCI_EVT_DISCONNECT_COMPLETE 0x05

#define HCI_OP_LE_SET_SCAN_ENABLE 0x200C
#define HCI_OP_LE_CREATE_CONN 0x200D

/* ========== SMP Pairing State Machine ========== */
typedef enum {
    PAIRING_IDLE,
    PAIRING_REQUEST_SENT,
    PAIRING_RESPONSE_RCVD,
    PAIRING_CONFIRM_SENT,
    PAIRING_RANDOM_EXCHANGED,
    PAIRING_CONFIRM_VALIDATED,      // ← NEW: Validation successful
    PAIRING_WAITING_FOR_KEY_DIST,   // ← NEW: Waiting for LTK/IRK/CSRK
    PAIRING_KEY_DIST_COMPLETE,      // ← NEW: All keys exchanged
    PAIRING_COMPLETE,
    PAIRING_FAILED
} pairing_state_t;

#define MAX_ACL_PACKET_SIZE 256
#define RING_BUF_COUNT 8
#define RING_BUF_MASK (RING_BUF_COUNT - 1)

static uint8_t ring_bufs[RING_BUF_COUNT][MAX_ACL_PACKET_SIZE];
static volatile uint8_t ring_prod = 0;
static volatile uint8_t ring_cons = 0;
static QueueHandle_t ring_desc_queue = NULL;

typedef struct {
    uint8_t buf_idx;
    uint16_t len;
} ring_desc_t;
// Forward declarations
static void handlehcieventinternal(const uint8_t *data, uint16_t len);

#ifndef BLELOG_HCI_EVT
#define BLELOG_HCI_EVT 4 // HCI Event is the 4th type (0=HCI_CMD, 1=HCI_EVT, 2=ACL, 3=SMP, 4=HCI_EVT)
#endif 

// Declare functions used by the ACL processing task (remove 'extern' if defined in this file, use 'static' if they are)
// Assuming handle_smp_packet and handle_hci_event_internal are defined later in this same file OR linked externally.
// Based on the error, handle_smp_packet is likely defined later as static, so let's use the static declaration style:
static void vhci_notify_host_send_available(void); // Assuming this existed elsewhere but wasn't visible

// Declare external function that handles HCI Events (needs to be implemented
// or located elsewhere in your code, but called from the task now)
// Declare external function that handles SMP packets
static void handle_smp_packet(const uint8_t *smp_pdu, uint16_t len, uint16_t handle);
static pairing_state_t pairing_state = PAIRING_IDLE;

/* ========== State & Globals ========== */
static EventGroupHandle_t hci_events = NULL;
#define HCI_EVT_RX_BIT (1 << 0)
#define HCI_CONN_COMPLETE_BIT (1 << 1)

#define MAX_PAIRING_ATTEMPTS 3
static uint8_t pairing_attempts = 0;
static bool target_found = false;
static bool connection_active = false;
static uint8_t target_addr[6];
static uint8_t target_addr_type = 0;
static uint16_t connection_handle = 0;
static volatile uint16_t last_cmd_opcode = 0;
static volatile uint8_t last_cmd_status = 0;

//pair trackers
static bool peer_confirm_received = false;
static uint32_t peer_passkey = 0;
static bool passkey_received = false;
// Add to globals (after existing pairing globals):
// Global ephemeral keys
static ble_sm_ecc_point_t our_ephemeral_pub;
static ble_sm_ecc_secret_t our_ephemeral_priv;
// Global log queue
QueueHandle_t blelogqueue = NULL;

static bool ephemeral_keys_generated = false;
uint8_t local_addr[6] = { 0 }; // device address
uint8_t local_addr_type = 0;   // device address type
static bool local_addr_received = false;
// CHANGE: Set fallback type to 0 and ensure bytes are Little Endian (LSB first)
// If your address is 84:1F:E8:15:AF:32, the array below is correct (LSB at index 0)
static uint8_t fallback_local_addr[6] = {0x32, 0xAF, 0x15, 0xE8, 0x1F, 0x84}; 
static uint8_t fallback_local_addr_type = 0; // CHANGE: Set to 0 (Public)
static uint8_t preq_pdu[7];
static uint8_t pres_pdu[7];
static uint8_t our_addr[6] = {0};
static uint8_t peer_addr[6] = {0};
static uint8_t iat = 0; // Our address type (0=public,1=random)
static uint8_t rat = 1; // Peer address type
static uint8_t peer_public_key[64];
static bool peer_public_key_received = false;
static uint8_t dhkey[32];
static uint8_t peer_confirm[16];
static uint8_t our_random[16];
static uint8_t peer_random[16];
static bool pairing_complete = false;
/* --- BLE SMP stored PDUs & state (for c1 debugging) --- */
static uint8_t stored_preq[7];
static uint8_t stored_pres[7];
static bool stored_preq_valid = false;
static bool stored_pres_valid = false;

static bool gatt_discovery_started = false;
static bool att_mtu_exchanged = false;
static bool conn_params_updated = false;
static uint16_t peer_mtu = 23;  // Default minimum MTU
static uint32_t keys_distribution_received = 0;  // Bitmask of received keys
static bool keepalive_running = false;

static void connection_task(void *arg);

/* ========== Helper Functions ========== */
static void send_hci(uint8_t *cmd, uint16_t len) {
    int retry = 50;
    while (!esp_vhci_host_check_send_available() && retry-- > 0)
        vTaskDelay(pdMS_TO_TICKS(1));
    esp_vhci_host_send_packet(cmd, len);
}


// Logging task - runs at low priority, drains queue
static void ble_logging_task(void *arg)
{
    blelogentry_t entry;

    while (1) {
        if (xQueueReceive(blelogqueue, &entry, pdMS_TO_TICKS(100)) == pdTRUE) {
            switch (entry.type) {
                case BLELOG_INIT:
                    // INIT: opcode holds HCI opcode
                    break;
                case BLELOG_SCAN:
                    // scan log
                    break;
                case BLELOG_CONNECT:
                    // connect log
                    break;
                case BLELOG_SMP:
                    // SMP: entry.opcode is SMP code
                    break;
                case BLELOG_ATT:
                    // ATT: entry.opcode is ATT opcode
                    break;
                case BLELOG_GATT:
                    // GATT: entry.data1 is MTU, etc.
                    break;
                case BLELOG_KEEPALIVE:
                    break;
                case BLELOG_ERROR:
                    // ERROR: entry.opcode is reason
                    break;
            }
        }
    }
}

static void keepalive_task(void *arg) {
    printf("[KEEPALIVE] Task started\n");
    
    while (connection_active) {
        vTaskDelay(pdMS_TO_TICKS(1500));  // Ping every 1.5 seconds
        
        // Send ATT Read By Type Request (0x08) to keep alive
        // This pings the device without breaking the connection
        uint8_t ping_pkt[] = {
            0x02,                    // HCI ACL packet type
            connection_handle & 0xFF, (connection_handle >> 8) & 0xFF,
            0x00, 0x00,              // Reserved
            0x08, 0x00,              // L2CAP length = 8 bytes
            0x04, 0x00,              // L2CAP CID = 0x0004 (ATT)
            0x08,                    // ATT opcode: Read By Type Request
            0x00, 0x00,              // Start handle = 0x0000
            0xFF, 0xFF,              // End handle = 0xFFFF
            0x01, 0x28               // UUID = 0x2801 (Primary Service)
        };
        
        send_hci(ping_pkt, sizeof(ping_pkt));
        printf("[KEEPALIVE] Sent ping\n");
    }
    
    printf("[KEEPALIVE] Task stopping\n");
    keepalive_running = false;
    vTaskDelete(NULL);
}
void send_read_bd_addr_cmd(void) {
    uint8_t cmd[] = {0x01, 0x09, 0x10, 0x00}; // HCI Read BD_ADDR opcode 0x1009
    send_hci(cmd, sizeof(cmd));
    printf("[HCI] Sent Read BD_ADDR command\n");
}

// Generate secure random for pairing
static int init_pairing_random(void) {
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    
    if (mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0) != 0) {
        return -1;
    }
    
    // Generate 16 random bytes
    if (mbedtls_ctr_drbg_random(&ctr_drbg, our_random, 16) != 0) {
        return -1;
    }
    
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    
    printf("[SMP] Generated secure random for pairing\n");
    printf("[LOG] Our random: ");
    for (int i = 0; i < 16; i++) printf("%02X ", our_random[i]);
    printf("\n");
    
    return 0;
}
static void send_smp_ltk(uint16_t handle) {
    /* 1. Generate and Send LTK (0x08) */
    uint8_t ltk[16];
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_entropy_context entropy;
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0);
    mbedtls_ctr_drbg_random(&ctr_drbg, ltk, 16);
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);

    printf("[SMP] Generated our LTK: ");
    for (int i = 0; i < 16; i++) printf("%02X ", ltk[i]);
    printf("\n");

    // Packet 1: Encryption Information (0x08)
    uint8_t ltk_payload[17];
    ltk_payload[0] = 0x08;  // Opcode
    memcpy(&ltk_payload[1], ltk, 16);

    // Build ACL packet for LTK
    uint16_t smp_len = 17;
    uint16_t l2cap_len = smp_len;
    uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;

    uint8_t *pkt = malloc(pkt_len);
    if (pkt) {
        size_t pos = 0;
        pkt[pos++] = 0x02;
        pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
        pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
        pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
        pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
        pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
        pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
        pkt[pos++] = (uint8_t)(cid & 0xFF);
        pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
        memcpy(&pkt[pos], ltk_payload, smp_len);

        printf("[SMP] Sending OUR LTK (Encryption Info 0x08)\n");
        send_hci(pkt, pkt_len);
        free(pkt);
    }
    
    // Give a tiny delay between packets
    vTaskDelay(pdMS_TO_TICKS(10));

    /* 2. Send Master Identification (0x09) */
    // EDIV (2 bytes) + Rand (8 bytes)
    // For Legacy Just Works, often set to 0 if not re-using keys
    uint8_t master_id_payload[11];
    master_id_payload[0] = 0x09;  // Opcode
    master_id_payload[1] = 0x00;  // EDIV LSB
    master_id_payload[2] = 0x00;  // EDIV MSB
    memset(&master_id_payload[3], 0, 8); // Rand (8 bytes) - zeroed

    smp_len = 11;
    l2cap_len = smp_len;
    data_total_len = 4 + l2cap_len;
    pkt_len = 1 + 2 + 2 + 4 + smp_len;

    pkt = malloc(pkt_len);
    if (pkt) {
        size_t pos = 0;
        pkt[pos++] = 0x02;
        pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
        pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
        pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
        pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
        pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
        pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
        pkt[pos++] = (uint8_t)(cid & 0xFF);
        pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
        memcpy(&pkt[pos], master_id_payload, smp_len);

        printf("[SMP] Sending Master Identification (0x09)\n");
        send_hci(pkt, pkt_len);
        free(pkt);
    }
}

/*    const uint8_t smp_payload[] = {
        0x01, // Pairing Request 
        0x03, // IO Capability: NoInputNoOutput 
        0x00, // OOB data: Not present 
        0x01, // AuthReq: Bonding 
        0x10, // MaxEncKeySize = 16 
        0x07, // Initiator Key Dist 
        0x07  // Responder Key Dist 
    };*/
/* ========== Send SMP Pairing Request ========== */
static void send_smp_pairing_request(uint16_t handle) {
    int retry = 100;
    while (!esp_vhci_host_check_send_available() && retry-- > 0) {
        vTaskDelay(pdMS_TO_TICKS(5));
    }
    if (retry <= 0) {
        printf("[SMP] VHCI STILL not ready after 500ms - aborting\n");
        return;
    }

    // IO Cap = NoInputNoOutput (0x03), OOB=0, AuthReq=0 (no MITM, no bonding)
    const uint8_t smp_payload[] = {
        0x01, 0x03, 0x00, 0x00, 0x10, 0x00, 0x00
    };
	//bonding scenario - MATCH nRF AuthReq (0x0D = SC+MITM+Bonding)
/*	const uint8_t smp_payload[] = {
		0x01, 0x03, 0x00, 0x0D, 0x10, 0x01, 0x01 // ← SC+MITM+Bonding to match peer!
	};*/
    // ⭐⭐⭐ STORE PREQ PDU FOR c1()
    memcpy(preq_pdu, smp_payload, 7);

    printf("[DEBUG] Stored PREQ: %02X %02X %02X %02X %02X %02X %02X\n",
           preq_pdu[0], preq_pdu[1], preq_pdu[2],
           preq_pdu[3], preq_pdu[4], preq_pdu[5], preq_pdu[6]);
               
    const uint16_t smp_len = sizeof(smp_payload);
    const uint16_t l2cap_len = smp_len;
    const uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12) | (0x00 << 14);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;

    uint8_t *pkt = (uint8_t *)malloc(pkt_len);
    if (!pkt) {
        printf("[SMP] malloc failed\n");
        return;
    }

    size_t pos = 0;
    pkt[pos++] = 0x02;  // HCI ACL
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], smp_payload, smp_len);
    pos += smp_len;

    printf("[SMP] Sending Pairing Request (No MITM, No Bonding) over L2CAP (handle=0x%04X, pkt_len=%u)\n", handle, (unsigned int)pkt_len);

    send_hci(pkt, pkt_len);
    free(pkt);

    pairing_state = PAIRING_REQUEST_SENT;
    pairing_attempts++;
}

// Function to be called on connection completion, set addresses and types here
// Called on LE Connection Complete to update addresses and pairing state
void on_connection_complete(uint8_t *local_mac, uint8_t local_addr_type,
                            uint8_t *remote_mac, uint8_t remote_addr_type,
                            uint16_t handle) {
    memcpy(our_addr, local_mac, 6);
    iat = local_addr_type;     // Initiator address type
    memcpy(peer_addr, remote_mac, 6);
    rat = remote_addr_type;    // Responder address type
    connection_handle = handle;

    pairing_complete = false;
    pairing_state = PAIRING_IDLE;

    printf("[LOG] Our Addr: %02X:%02X:%02X:%02X:%02X:%02X (type %d)\n",
           our_addr[0], our_addr[1], our_addr[2], our_addr[3], our_addr[4], our_addr[5], iat);
    printf("[LOG] Peer Addr: %02X:%02X:%02X:%02X:%02X:%02X (type %d)\n",
           peer_addr[0], peer_addr[1], peer_addr[2], peer_addr[3], peer_addr[4], peer_addr[5], rat);

    // Initiate SMP pairing request
    send_smp_pairing_request(handle);
}
// Fill buffer with passkey bytes for experimental confirm/random (not cryptographically correct)
static void fill_passkey_bytes(uint8_t *buf, uint32_t passkey, uint8_t smp_code) {
    buf[0] = smp_code;  // SMP code (e.g. 0x03 for confirm, 0x04 for random)
    memset(&buf[1], 0, 16);
    buf[1] = (uint8_t)(passkey & 0xFF);
    buf[2] = (uint8_t)((passkey >> 8) & 0xFF);
    buf[3] = (uint8_t)((passkey >> 16) & 0xFF);
    buf[4] = (uint8_t)((passkey >> 24) & 0xFF);
    printf("[SMP-EXPERIMENTAL] Using passkey %06u for bytes 1-4\n", passkey);
}

static void send_smp_pairing_confirm(uint16_t handle) {
    uint8_t confirm_payload[17];
    confirm_payload[0] = 0x03;

    uint8_t tk[16] = {0};  // Just Works TK, all zeros
	printf("[LOG] Pairing Request PDU: ");
	for (int i=0; i<7; i++) printf("%02X ", preq_pdu[i]);
	printf("\n");

	printf("[LOG] Pairing Response PDU: ");
	for (int i=0; i<7; i++) printf("%02X ", pres_pdu[i]);
	printf("\n");

	printf("[LOG] Our random: ");
	for (int i=0; i<16; i++) printf("%02X ", our_random[i]);
	printf("\n");
    printf("[LOG] Our Address: ");
    for (int i=0; i<6; i++) printf("%02X ", our_addr[i]);
    printf(" (type=%d)\n", iat);
    
    printf("[LOG] Peer Address: ");
    for (int i=0; i<6; i++) printf("%02X ", peer_addr[i]);
    printf(" (type=%d)\n", rat);
    
    printf("[LOG] Address types: iat=%d, rat=%d\n", iat, rat);
	// CHANGE: Use a local aligned buffer for the c1 output
    uint8_t local_confirm[16];    	
    int rc = ble_sm_alg_c1(tk, our_random, preq_pdu, pres_pdu, iat, rat,
                           our_addr, peer_addr, local_confirm);
    if (rc != 0) {
        printf("[SMP] SMP c1 confirm calculation failed\n");
        return;
    }
	// Copy the result into the payload
    memcpy(&confirm_payload[1], local_confirm, 16);    
    printf("[LOG] Computed Confirm: ");
    for (int i = 0; i < 16; i++) printf("%02X ", confirm_payload[1 + i]);
    printf("\n");
    printf("[SMP] SMP c1 Pairing Confirm computed\n");

    // Send confirm payload over ACL/L2CAP as usual
    const uint16_t smp_len = 17;
    const uint16_t l2cap_len = smp_len;
    const uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;

    uint8_t *pkt = malloc(pkt_len);
    if (!pkt) {
        printf("[SMP-CRYPTO] malloc failed\n");
        return;
    }

    size_t pos = 0;
    pkt[pos++] = 0x02;
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], confirm_payload, smp_len);

    printf("[SMP-CRYPTO] Sending Pairing Confirm with SMP c1 value\n");
    send_hci(pkt, pkt_len);
    free(pkt);

    pairing_state = PAIRING_CONFIRM_SENT;
}

static void send_smp_pairing_random(uint16_t handle) {
    uint8_t random_payload[17];
    random_payload[0] = 0x04;
    memcpy(&random_payload[1], our_random, 16);
    
    printf("[SMP-CRYPTO] Sending Pairing Random\n");
	printf("[LOG] Our random: ");
	for (int i=0; i<16; i++) printf("%02X ", our_random[i]);
	printf("\n");    
    
    // Send ACL/L2CAP packet
    const uint16_t smp_len = 17;
    const uint16_t l2cap_len = smp_len;
    const uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;
    
    uint8_t *pkt = malloc(pkt_len);
    if (!pkt) {
        printf("[SMP-CRYPTO] malloc failed\n");
        return;
    }
    
    size_t pos = 0;
    pkt[pos++] = 0x02;
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], random_payload, smp_len);
    
    send_hci(pkt, pkt_len);
    free(pkt);
    
    pairing_state = PAIRING_RANDOM_EXCHANGED;
}

static void send_att_exchange_mtu(uint16_t handle) {
    printf("[ATT] Initiating Exchange MTU\n");
    
    uint8_t att_pdu[3];  // ✅ FIXED: 3-byte array
    att_pdu[0] = 0x02;   // Exchange MTU Request opcode
    
    uint16_t client_mtu = 247;
    att_pdu[1] = (uint8_t)(client_mtu & 0xFF);      // LSB
    att_pdu[2] = (uint8_t)((client_mtu >> 8) & 0xFF); // MSB
    
    // Build ACL packet with ATT in L2CAP
    const uint16_t l2cap_len = 3;
    const uint16_t cid = 0x0004;  // ATT channel
    
    uint16_t pb_bc = (0x02 << 12);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    
    size_t pkt_len = 1 + 2 + 2 + 4 + 3;
    uint8_t *pkt = malloc(pkt_len);
    
    if (!pkt) return;
    
    size_t pos = 0;
    pkt[pos++] = 0x02;  // HCI ACL packet type
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], att_pdu, 3);  // ✅ FIXED: Now copies 3 bytes from array
    
    printf("[ATT] Sending Exchange MTU Request (MTU=%u)\n", client_mtu);
    send_hci(pkt, pkt_len);
    free(pkt);
    
    att_mtu_exchanged = false;  // Waiting for response
}

/* ========== SMP Pairing State Machine Handler ========== */
// SMP packet handler additions/modifications:

// SMP packet handler: process SMP messages from ACL
static void handle_smp_packet(const uint8_t *smp, uint16_t smp_len, uint16_t handle) {
    static uint8_t expected_confirm[16];
    static uint8_t tk[16] = {0}; // Just Works TK, all zeros

    uint8_t smp_code = smp[0];
    printf("[SMP_STATE] Received SMP code 0x%02X\n", smp_code);

    switch (smp_code) {
        case 0x01: // Pairing Request
            if (smp_len >= 7) {
                //memcpy(preq_pdu, smp, 7);
                printf("[LOG] Pairing Request PDU from peripheral: ");
                for (int i = 0; i < 7; i++) printf("%02X ", preq_pdu[i]);
                printf("\n");
            }
            break;

        case 0x02: // Pairing Response
            if (smp_len >= 7) {
                memcpy(pres_pdu, smp, 7);
                printf("[LOG] Pairing Response PDU: ");
                for (int i = 0; i < 7; i++) printf("%02X ", pres_pdu[i]);
                printf("\n");
                pairing_state = PAIRING_RESPONSE_RCVD;
				if (init_pairing_random() != 0) {
				    printf("[SMP] Failed to generate random!\n");
				    return;
				}                
                printf("[SMP] Sending Pairing Confirm...\n");
                send_smp_pairing_confirm(handle);
            }
            break;

        case 0x03: // Pairing Confirm
            if (smp_len >= 17) {
                memcpy(peer_confirm, &smp[1], 16);
                printf("[LOG] Peer Pairing Confirm: ");
                for (int i = 0; i < 16; i++) printf("%02X ", peer_confirm[i]);
                printf("\n");
                pairing_state = PAIRING_CONFIRM_SENT;
                printf("[SMP] Sending OUR Pairing Random...\n");
                send_smp_pairing_random(handle);
            }
            break;

		case 0x04:  // Pairing Random
			if (smp_len >= 17) {
				memcpy(peer_random, &smp[1], 16);  // ✅ FIXED: Skip opcode byte (smp[0])
				printf("[LOG] Peer Pairing Random: ");
				for (int i = 0; i < 16; i++) printf("%02X ", peer_random[i]);
				printf("\n");
				
				uint8_t expected_confirm[16];  // ✅ FIXED: 16-byte array
				uint8_t tk[16] = {0};          // ✅ FIXED: 16-byte array (Just Works)
				
				int rc = ble_sm_alg_c1(tk, peer_random, preq_pdu, pres_pdu, iat, rat,
				                       our_addr, peer_addr, expected_confirm);
				if (rc != 0) {
				    printf("[SMP-CRYPTO] c1() failed\n");
				    pairing_state = PAIRING_FAILED;
				    return;
				}
				
				printf("[LOG] Expected Confirm: ");
				for (int i = 0; i < 16; i++) printf("%02X ", expected_confirm[i]);  // ✅ FIXED
				printf("\n");
				
				printf("[LOG] Peer's Confirm:   ");
				for (int i = 0; i < 16; i++) printf("%02X ", peer_confirm[i]);
				printf("\n");
				
				if (memcmp(peer_confirm, expected_confirm, 16) != 0) {  // ✅ FIXED
				    printf("[SMP] ✗ Peer Confirm MISMATCH - pairing failed\n");
				    pairing_state = PAIRING_FAILED;
				    return;
				}
				
				printf("[SMP] ✓ Pairing confirm validated successfully\n");
				pairing_complete = true;
				pairing_state = PAIRING_CONFIRM_VALIDATED;
				
				// ✅ FIXED: Index arrays properly
				uint8_t responder_key_dist = pres_pdu[6];
				uint8_t initiator_key_dist = preq_pdu[6];
				
				printf("[SMP] Key Distribution Flags:\n");
				printf("  Responder will send: 0x%02X\n", responder_key_dist);
				printf("    - LTK: %s\n", (responder_key_dist & 0x01) ? "YES" : "NO");
				printf("    - IRK: %s\n", (responder_key_dist & 0x02) ? "YES" : "NO");
				printf("    - CSRK: %s\n", (responder_key_dist & 0x04) ? "YES" : "NO");
				printf("  Initiator should send: 0x%02X\n", initiator_key_dist);
				
				if (initiator_key_dist == 0x00) {
					printf("[SMP] ✓ No keys to exchange (Just Works - No Bonding)\n");
					pairing_state = PAIRING_KEY_DIST_COMPLETE;
					
					if (!gatt_discovery_started) {
						gatt_discovery_started = true;
						printf("[SMP->GATT] Starting ATT MTU exchange (pairing complete!)\n");
						send_att_exchange_mtu(connection_handle);
					}
				}

			}
			break;
/*		case 0x06:  // SMP Public Key (ECDH - for SC pairing)
			if (smp_len >= 65) {
				memcpy(peer_public_key, &smp, 64);
				peer_public_key_received = true;
				printf("[SMP] Received peer public key\n");
			}
			break;*/

		// SMP Encryption Information (LTK) - code 0x08
		case 0x08:
			if (smp_len >= 17) {
				uint8_t ltk[16];  // ✅ FIXED: 16-byte array
				memcpy(ltk, &smp[1], 16);  // ✅ FIXED: Skip opcode, copy 16 bytes
				
				printf("[SMP] Received Encryption Information (LTK):\n");
				for (int i = 0; i < 16; i++) printf("%02X ", ltk[i]);  // ✅ FIXED
				printf("\n");
				keys_distribution_received |= 0x01;
				printf("[SMP] Keys received so far: 0x%02X\n", keys_distribution_received);
			}
			break;

		// SMP Master Identification - code 0x09
		case 0x09:
			if (smp_len >= 11) {
				uint16_t ediv = (uint16_t)smp[1] | ((uint16_t)smp[2] << 8);  // ✅ FIXED: Index array
				printf("[SMP] Received Master Identification: EDIV=0x%04X\n", ediv);
				printf("      RAND: ");
				for (int i = 0; i < 8; i++) printf("%02X ", smp[3 + i]);
				printf("\n");
			}
			break;

		// SMP Identity Information (IRK) - code 0x0A
		case 0x0A:
			if (smp_len >= 17) {
				printf("[SMP] Received Identity Information (IRK)\n");
				keys_distribution_received |= 0x02;
			}
			break;

		// SMP Identity Address Information - code 0x0B
		case 0x0B:
			if (smp_len >= 8) {
				uint8_t addr_type = smp[1];  // ✅ FIXED: Index array
				printf("[SMP] Received Identity Address: type=%d, addr=", addr_type);
				for (int i = 0; i < 6; i++) printf("%02X%s", smp[2+i], i<5?":":"");
				printf("\n");
			}
			break;
		// SMP Signing Information (CSRK) - code 0x0C
/*		case 0x0C:
			if (smp_len >= 17) {
				printf("[SMP] Received Signing Information (CSRK)\n");
				keys_distribution_received |= 0x04;
			}
			break;        case 0x0C: // SMP Public Key
            if (smp_len >= 65) {
                memcpy(peer_public_key, &smp[1], 64);
                peer_public_key_received = true;
                printf("[LOG] Peer Public Key: ");
                for (int i = 0; i < 64; i++) printf("%02X ", peer_public_key[i]);
                printf("\n");

                int rc = ble_sm_alg_gen_dhkey(peer_public_key, &peer_public_key[32],
                                             our_ephemeral_priv.data, dhkey);
                if (rc != 0) {
                    printf("[SMP-CRYPTO] DHKey generation failed\n");
                    pairing_state = PAIRING_FAILED;
                    return;
                }

                printf("[LOG] DHKey: ");
                for (int i = 0; i < 32; i++) printf("%02X ", dhkey[i]);
                printf("\n");
            }
            break;*/

        case 0x05: // Pairing Failed
            printf("[SMP] Pairing Failed with reason 0x%02X\n", smp[1]);
            pairing_state = PAIRING_FAILED;
            break;

        default:
            printf("[SMP] Unknown SMP code 0x%02X\n", smp_code);
            break;
    }
}
// ============================================================================
// ULTRA-FAST ISR - 10 cycles max (pointer only)
// ============================================================================
static int vhci_recv_handler(uint8_t *data, uint16_t len) {
    if (!data || len < 1 || len > MAX_ACL_PACKET_SIZE) return 0;
    
    // Atomic producer index
    uint8_t prod = ring_prod;
    uint8_t next_prod = (prod + 1) & RING_BUF_MASK;
    
    // Drop if full (rare, prevents ISR block)
    if (next_prod == ring_cons) return 0;
    
    // Copy to static ring buffer (controller UART → static)
    memcpy(ring_bufs[prod], data, len);
    
    // Queue descriptor only (4 bytes)
    ring_desc_t desc = { .buf_idx = prod, .len = len };
    BaseType_t xWoken = pdFALSE;
    
    if (xQueueSendFromISR(ring_desc_queue, &desc, &xWoken) == pdTRUE) {
        ring_prod = next_prod;  // Commit only on success
    }
    
    portYIELD_FROM_ISR();
    return 0;
}

/**
 * ACL Processing Task & ISR Handler Implementation
 * 
 * This is the corrected implementation for ISR + task separation.
 * Copy and paste these functions into your ble_hooks.c file, replacing
 * the broken versions.
 */

// ============================================================================
// TASK: Process ring buffer (safe context)
// ============================================================================
static void acl_processing_task(void *arg) {
    ring_desc_t desc;
    printf("[ACL_TASK] Zero-copy ring buffer started\n");
    
    while (1) {
        if (xQueueReceive(ring_desc_queue, &desc, portMAX_DELAY) == pdTRUE) {
            const uint8_t *data = ring_bufs[desc.buf_idx];
            uint16_t len = desc.len;
            
            // Process packet (existing logic)
            uint8_t packet_type = data[0];
            
            if (packet_type == 0x04) {
                handlehcieventinternal(data, len);
            } else if (packet_type == 0x02) {
                // Existing ACL handling (unchanged)
                if (len < 5) continue;
                uint16_t handle_field = (uint16_t)data[1] | ((uint16_t)data[2] << 8);
                uint16_t handle = handle_field & 0x0FFF;
                size_t offset = 1 + 2 + 2;
                
                if ((size_t)len < offset + 4) continue;
                uint16_t l2cap_len = (uint16_t)data[offset] | ((uint16_t)data[offset+1] << 8);
                uint16_t l2cap_cid = (uint16_t)data[offset+2] | ((uint16_t)data[offset+3] << 8);
                offset += 4;
                
                if (l2cap_cid == 0x0006 && connection_handle == handle) {
                    if (l2cap_len > 0 && (size_t)l2cap_len <= (len - offset)) {
                        const uint8_t *smp = &data[offset];
                        handle_smp_packet(smp, l2cap_len, handle);
                    }
                } else if (l2cap_cid == 0x0004 && connection_handle == handle) {
                    // Existing ATT handling (unchanged)
                    if ((size_t)len < offset + 1) continue;
                    const uint8_t *att_pdu = &data[offset];
                    uint8_t att_opcode = att_pdu[0];
                    printf("[ATT] Received ATT opcode: 0x%02X\n", att_opcode);
                    
                    if (att_opcode == 0x03) {
                        if ((size_t)len < offset + 3) continue;
                        uint16_t server_mtu = (uint16_t)att_pdu[1] | ((uint16_t)att_pdu[2] << 8);
                        peer_mtu = (server_mtu < 247) ? server_mtu : 247;
                        att_mtu_exchanged = true;
                        printf("[GATT] MTU Exchange Complete. Peer MTU: %u\n", peer_mtu);
                        
                        // Connection params + keepalive (unchanged)
                        if (att_mtu_exchanged && !conn_params_updated) {
                            uint8_t conn_update[] = {
                                HCI_PACKET_TYPE_CMD, 0x18, 0x12, 0x11,
                                connection_handle & 0xFF, (connection_handle >> 8) & 0xFF,
                                0x28, 0x00, 0xF4, 0x01, 0x00, 0xF4, 0x01, 0x00, 0x00
                            };
                            send_hci(conn_update, sizeof(conn_update));
                            conn_params_updated = true;
                            printf("[CONNECT] Connection parameters updated\n");
                        }
                        if (!keepalive_running) {
                            keepalive_running = true;
                            xTaskCreate(keepalive_task, "keepalive", 4096, NULL, 3, NULL);
                        }
                    }
                }
            }
        }
    }
}


/* ========== Improved Watchdog ========== */
static void pairing_watchdog(void *arg) {
    const int max_retries = 50;  // ~100 seconds total monitoring
    int timeout_count = 0;
    bool pairing_phase_done = false;
    uint32_t pairing_phase_done_time = 0;
    
    for (int retry = 0; retry < max_retries; retry++) {
        vTaskDelay(pdMS_TO_TICKS(2000));  // Check every 2 seconds
        
        // Exit only if connection is lost
        if (!connection_active) {
            printf("[WATCHDOG] Connection lost\n");
            break;
        }
        
        // Detect transition to key distribution phase
        if (pairing_state == PAIRING_CONFIRM_VALIDATED && !pairing_phase_done) {
            pairing_phase_done = true;
            pairing_phase_done_time = xTaskGetTickCount();
            printf("[WATCHDOG] ✓ Pairing confirmed - waiting for key exchange (60s timeout)\n");
            // ✓ CRITICAL: DON'T EXIT - keep monitoring
        }
        
        // Exit only on actual failure
        if (pairing_state == PAIRING_FAILED) {
            printf("[WATCHDOG] ✗ Pairing failed\n");
            break;
        }
        
        // Timeout after pairing phase done + 60 seconds
        if (pairing_phase_done) {
            uint32_t elapsed_ticks = xTaskGetTickCount() - pairing_phase_done_time;
            uint32_t elapsed_ms = (elapsed_ticks * 1000) / configTICK_RATE_HZ;
            
            if (elapsed_ms > 10000) {
                printf("[WATCHDOG] Timeout waiting for key exchange (60s)\n");
                break;
            }
            
            // Log progress every 10 seconds
            if ((timeout_count % 5) == 0) {
                printf("[WATCHDOG] Still monitoring key exchange (%.1fs elapsed, keys=0x%x)\n",
                       elapsed_ms / 1000.0f, keys_distribution_received);
            }
        }
        
        timeout_count++;
    }
    
    printf("[WATCHDOG] Task complete\n");
    vTaskDelete(NULL);
}

static bool wait_for_cmd_complete_opcode(uint16_t opcode, TickType_t timeout_ms) {
    TickType_t end = xTaskGetTickCount() + pdMS_TO_TICKS(timeout_ms);
    while (xTaskGetTickCount() < end) {
        EventBits_t bits = xEventGroupWaitBits(hci_events, HCI_EVT_RX_BIT, pdTRUE, pdFALSE, pdMS_TO_TICKS(50));
        if (bits & HCI_EVT_RX_BIT) {
            if (last_cmd_opcode == opcode) return true;
        }
    }
    return false;
}

/* ========== Connect Command ========== */
static void send_create_connection(void) {
    printf("[CONNECT] Initiating connection to %02x:%02x:%02x:%02x:%02x:%02x\n",
           target_addr[5], target_addr[4], target_addr[3],
           target_addr[2], target_addr[1], target_addr[0]);
    
    uint8_t cmd_conn[] = {
        HCI_PACKET_TYPE_CMD,
        (HCI_OP_LE_CREATE_CONN & 0xFF), (uint8_t)(HCI_OP_LE_CREATE_CONN >> 8),
        0x19, /* Param Len */
        0x60, 0x00, 0x30, 0x00, 0x00, target_addr_type,
        target_addr[0], target_addr[1], target_addr[2], target_addr[3], target_addr[4], target_addr[5],
        0x00, // <--- This byte is Own_Addr_Type. 0x00 = Public.
        0x18, 0x00, 0x28, 0x00, 0x00, 0x00, 0xF4, 0x01, 0x00, 0x00, 0x00, 0x00
    };
    send_hci(cmd_conn, sizeof(cmd_conn));
}

/* ========== Debug Print ========== */
static void debug_print_hci_event(uint8_t *data, uint16_t len) {
    if (!data || len < 3) return;
    uint8_t evt_code = data[1];
    uint8_t evt_len = data[2];
    printf("[HCI_EVT] Type: 0x%02X, Code: 0x%02X, Len: %d, Data: ", data[0], evt_code, evt_len);
    for (int i = 0; i < len && i < 48; i++) printf("%02X ", data[i]);
    if (len > 48) printf("...");
    printf("\n");
    
    if (evt_code == HCI_EVT_LE_META && len >= 4) {
        uint8_t sub_evt = data[3];
        printf(" [LE_META] SubEvent: 0x%02X", sub_evt);
        switch (sub_evt) {
            case 0x01: printf(" (LE_CONN_COMPLETE)\n"); break;
            case 0x02: printf(" (LE_ADV_REPORT)\n"); break;
            case 0x08: printf(" (LE_PASSKEY_DISPLAY)\n"); break;
            default: printf(" (UNKNOWN)\n"); break;
        }
    }
}
// ============================================================================
// HANDLE HCI EVENTS - Called from acl_processing_task (task context)
// ============================================================================
// This function processes HCI events safely (no ISR context).
// It's where we handle advertising reports, connection complete, etc.

static void handlehcieventinternal(const uint8_t *data, uint16_t len) {
    uint8_t event_code = data[1];
    
    if (len < 3) return;
    
    switch (event_code) {
        
        // ================================================================
        // 0x0E: Command Complete
        // ================================================================
        case 0x0E: {
            if (len >= 7) {
                uint16_t opcode = (uint16_t)data[4] | ((uint16_t)data[5] << 8);
                uint8_t status = data[6];
                printf("[HCI EVT] Command Complete. Opcode: 0x%04X, Status: 0x%02X\n", opcode, status);
                
                last_cmd_opcode = opcode;
                last_cmd_status = status;
                if (hci_events) xEventGroupSetBits(hci_events, HCI_EVT_RX_BIT);
            }
            break;
        }
        
        // ================================================================
        // 0x3E: LE Meta Event
        // ================================================================
        case 0x3E: {
            if (len >= 4) {
                uint8_t sub_evt = data[3];
                
                // ============================================================
                // 0x02: LE Advertising Report
                // ============================================================
                if (sub_evt == 0x02 && !target_found) {
                    if (len >= 12) {
                        uint8_t *p = (uint8_t *)&data[5];
                        uint8_t addr_type = p[1];
                        uint8_t *addr = &p[2];
                        uint8_t data_len = p[8];
                        uint8_t *adv_data = &p[9];
                        
                        printf("[SCAN] Advertising report from %02X:%02X:%02X:%02X:%02X:%02X\n",
                               addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
                        
                        // Search for target name in advertising data
                        int pos = 0;
                        while (pos < data_len) {
                            uint8_t ad_len = adv_data[pos];
                            if (ad_len == 0 || pos + 1 + ad_len > data_len) break;
                            
                            uint8_t ad_type = adv_data[pos + 1];
                            uint8_t val_len = ad_len - 1;
                            uint8_t *val = &adv_data[pos + 2];
                            
                            // Complete (0x09) or Incomplete (0x08) Local Name
                            if ((ad_type == 0x09 || ad_type == 0x08) && 
                                val_len == strlen(TARGET_DEVICE_NAME)) {
                                
                                if (memcmp(val, TARGET_DEVICE_NAME, val_len) == 0) {
                                    // FOUND TARGET!
                                    memcpy(target_addr, addr, 6);
                                    target_addr_type = addr_type;
                                    target_found = true;
                                    
                                    printf("[SCAN] ✓ Found target device: %02X:%02X:%02X:%02X:%02X:%02X\n",
                                           addr[5], addr[4], addr[3], addr[2], addr[1], addr[0]);
                                    
                                    // Stop scanning
                                    uint8_t stop_scan[] = {HCI_PACKET_TYPE_CMD, 0x0C, 0x20, 0x02, 0x00, 0x00};
                                    send_hci(stop_scan, sizeof(stop_scan));
                                    
                                    // Create connection task
                                    xTaskCreate(connection_task, "conn_task", 4096, NULL, 5, NULL);
                                    return;
                                }
                            }
                            pos += 1 + ad_len;
                        }
                    }
                }
                
                // ============================================================
                // 0x01: LE Connection Complete
                // ============================================================
                else if (sub_evt == 0x01) {
                    if (len >= 20) {
                        uint8_t status = data[4];
                        uint16_t handle = (uint16_t)data[5] | ((uint16_t)data[6] << 8);
                        
                        if (status == 0x00) {
                            connection_handle = handle;
                            connection_active = true;
                            
                            printf("[CONNECT] ✓ Connected! Handle: 0x%04X\n", handle);
                            BLELOGISR(BLELOG_CONNECT, handle, 0, 0, 0);
                            
                            // Trigger connection callback to start pairing
                            if (local_addr_received) {
                                on_connection_complete(local_addr, local_addr_type, 
                                                      target_addr, target_addr_type, handle);
                            } else {
                                on_connection_complete(fallback_local_addr, fallback_local_addr_type,
                                                      target_addr, target_addr_type, handle);
                            }
                            
                            // Start pairing watchdog
                            xTaskCreate(pairing_watchdog, "ble_watchdog", 4096, NULL, 4, NULL);
                        } else {
                            printf("[CONNECT] ✗ Connection failed! Status: 0x%02X\n", status);
                        }
                    }
                }
            }
            break;
        }
        
        // ================================================================
        // 0x05: Disconnect Complete
        // ================================================================
        case 0x05: {
            if (len >= 7) {
                uint8_t status = data[3];
                uint16_t handle = (uint16_t)data[4] | ((uint16_t)data[5] << 8);
                uint8_t reason = data[6];
                
                printf("[DISCONNECT] Handle: 0x%04X, Reason: 0x%02X\n", handle, reason);
                BLELOGISR(BLELOG_ERROR, handle, reason, 0, 0);
                
                if (connection_active && handle == connection_handle) {
                    connection_active = false;
                    connection_handle = 0;
                    pairing_state = PAIRING_IDLE;
                }
            }
            break;
        }
        
        default:
            printf("[HCI EVT] Unhandled event code: 0x%02X\n", event_code);
            break;
    }
}
static void connection_task(void *arg) {
    const uint16_t expected_opcode = HCI_OP_LE_SET_SCAN_ENABLE;
    const TickType_t timeout_ms = 500;
    
    printf("[CONNECT_TASK] Waiting for Stop-Scan (opcode 0x%04X) completion\n", expected_opcode);
    
    bool ok = wait_for_cmd_complete_opcode(expected_opcode, timeout_ms);
    if (!ok) {
        printf("[CONNECT_TASK] Stop-scan timeout, proceeding anyway\n");
    }
    
    vTaskDelay(pdMS_TO_TICKS(50));
    send_create_connection();
    vTaskDelay(pdMS_TO_TICKS(10));
    vTaskDelete(NULL);
}

// ============================================================================
// VHCI CALLBACK REGISTRATION
// ============================================================================
// This registers our ISR handler with the ESP32 Bluetooth stack.

// VHCI callbacks (unchanged)
static void vhci_send_available_handler(void) {}

static const esp_vhci_host_callback_t vhci_cbs = {
    .notify_host_recv = vhci_recv_handler,
    .notify_host_send_available = vhci_send_available_handler
};

static void start_process(void) {
    printf("[INIT] Starting BLE HCI process...\n");
    
    uint8_t cmd_reset[] = { 0x01, 0x03, 0x0C, 0x00 };
    send_hci(cmd_reset, sizeof(cmd_reset));
    
    vTaskDelay(pdMS_TO_TICKS(200)); 
    send_read_bd_addr_cmd();
    vTaskDelay(pdMS_TO_TICKS(200)); 
    
    uint8_t cmd_evt_mask[] = { 0x01, 0x01, 0x0C, 0x08, 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
    send_hci(cmd_evt_mask, sizeof(cmd_evt_mask));
    
    uint8_t cmd_le_evt_mask[] = { 0x01, 0x01, 0x20, 0x08, 0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };
    send_hci(cmd_le_evt_mask, sizeof(cmd_le_evt_mask));
    
    uint8_t cmd_scan_params[] = { 0x01, 0x0B, 0x20, 0x07, 0x01, 0x60, 0x00, 0x60, 0x00, 0x00, 0x00 };
    send_hci(cmd_scan_params, sizeof(cmd_scan_params));
    
    printf("[SCAN] Starting scan for '%s'...\n", TARGET_DEVICE_NAME);
    uint8_t cmd_scan_enable[] = { 0x01, 0x0C, 0x20, 0x02, 0x01, 0x00 };
    send_hci(cmd_scan_enable, sizeof(cmd_scan_enable));
}

static void main_task(void *arg) {
    while (1) vTaskDelay(pdMS_TO_TICKS(10000));
}



// ============================================================================
// Updated ble_main() - Initialize ring buffer
// ============================================================================
void ble_main(void) {
    printf("starting ble init\n");
    
    nvs_flash_init();
    esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT);
    
    esp_bt_controller_config_t cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    esp_bt_controller_init(&cfg);
    esp_bt_controller_enable(ESP_BT_MODE_BLE);
    
    hci_events = xEventGroupCreate();
    blelogqueue = xQueueCreate(50, sizeof(blelogentry_t));
    
    // ✅ ZERO-COPY RING BUFFER 
    ring_desc_queue = xQueueCreate(RING_BUF_COUNT, sizeof(ring_desc_t));
    ring_prod = 0;
    ring_cons = 0;
    
    xTaskCreate(ble_logging_task, "blelogger", 2048, NULL, 1, NULL);
    xTaskCreate(acl_processing_task, "acl_proc", 4096, NULL, 2, NULL);  // PRIORITY 2
    
    esp_vhci_host_register_callback(&vhci_cbs);
    start_process();
    xTaskCreate(main_task, "main", 4096, NULL, 5, NULL);
    
    printf("ble main end - ZERO-COPY VHCI\n");
}

