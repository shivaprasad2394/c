// smp_crypto_alg.c - NimBLE SMP crypto for Just Works pairing with ESP-IDF mbedTLS private members

// smp_crypto_alg.c - FIXED VERSION
// SMP crypto for Just Works pairing with complete c1 implementation

#include <string.h>
#include "smp_crypto.h"

#define BLE_HS_EUNKNOWN 1

// Helper: Swap bytes (Little Endian <-> Big Endian)
static inline void swap_buf(uint8_t *dst, const uint8_t *src, size_t len) {
    for (size_t i = 0; i < len; i++) {
        dst[i] = src[len - 1 - i];
    }
}

static inline void swap_in_place(uint8_t *buf, size_t len) {
    for (size_t i = 0; i < len / 2; i++) {
        uint8_t tmp = buf[i];
        buf[i] = buf[len - 1 - i];
        buf[len - 1 - i] = tmp;
    }
}

static void ble_sm_alg_xor_128(const uint8_t *p, const uint8_t *q, uint8_t *r) {
    for (int i = 0; i < 16; i++) {
        r[i] = p[i] ^ q[i];
    }
}


int ble_sm_alg_encrypt(const uint8_t *key, const uint8_t *plaintext, uint8_t *enc_data) {
    // FORCE ALIGNMENT: ESP32 hardware AES requires 32-bit alignment
    uint8_t tmp_key[16] __attribute__((aligned(4)));
    uint8_t tmp_plain[16] __attribute__((aligned(4)));
    uint8_t tmp_enc[16] __attribute__((aligned(4)));

    // Swap key to Big Endian for AES engine
    swap_buf(tmp_key, key, 16);
    
    mbedtls_aes_context s;
    mbedtls_aes_init(&s);
    
    if (mbedtls_aes_setkey_enc(&s, tmp_key, 128) != 0) {
        mbedtls_aes_free(&s);
        return BLE_HS_EUNKNOWN;
    }
    
    // Swap plaintext to Big Endian
    swap_buf(tmp_plain, plaintext, 16);
    
    // Encrypt (Source and Dest must be aligned/valid)
    if (mbedtls_aes_crypt_ecb(&s, MBEDTLS_AES_ENCRYPT, tmp_plain, tmp_enc) != 0) {
        mbedtls_aes_free(&s);
        return BLE_HS_EUNKNOWN;
    }
    
    mbedtls_aes_free(&s);
    
    // Swap result back to Little Endian
    swap_in_place(tmp_enc, 16);
    
    memcpy(enc_data, tmp_enc, 16);
    return 0;
}
int ble_sm_alg_aes_cmac(const uint8_t *key, const uint8_t *in, size_t len, uint8_t *out) {
    int rc = BLE_HS_EUNKNOWN;
    mbedtls_cipher_context_t ctx = {0};
    const mbedtls_cipher_info_t *cipher_info;
    
    mbedtls_cipher_init(&ctx);
    cipher_info = mbedtls_cipher_info_from_type(MBEDTLS_CIPHER_AES_128_ECB);
    
    if (cipher_info == NULL) goto exit;
    if (mbedtls_cipher_setup(&ctx, cipher_info) != 0) goto exit;
    
    rc = mbedtls_cipher_cmac_starts(&ctx, key, 128);
    if (rc != 0) goto exit;
    
    rc = mbedtls_cipher_cmac_update(&ctx, in, len);
    if (rc != 0) goto exit;
    
    rc = mbedtls_cipher_cmac_finish(&ctx, out);
    
exit:
    mbedtls_cipher_free(&ctx);
    return rc;
}

int ble_sm_alg_f4(const uint8_t *u, const uint8_t *v, const uint8_t *x, uint8_t z, uint8_t *out_enc_data) {
    uint8_t xs[16];
    uint8_t m[65];
    int rc;
    
    swap_buf(m, u, 32);
    swap_buf(m + 32, v, 32);
    m[64] = z;
    
    swap_buf(xs, x, 16);
    
    rc = ble_sm_alg_aes_cmac(xs, m, sizeof(m), out_enc_data);
    if (rc != 0) return BLE_HS_EUNKNOWN;
    
    swap_in_place(out_enc_data, 16);
    
    return 0;
}

static mbedtls_ecp_keypair s_keypair;

int ble_sm_alg_gen_key_pair(uint8_t *pub, uint8_t *priv) {
    int rc = BLE_HS_EUNKNOWN;
    mbedtls_entropy_context entropy = {0};
    mbedtls_ctr_drbg_context ctr_drbg = {0};
    size_t olen = 0;
    uint8_t pub_bin[65] = {0};
    
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_ecp_keypair_free(&s_keypair);
    mbedtls_ecp_keypair_init(&s_keypair);
    
    if ((rc = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0)) != 0) goto exit;
    if ((rc = mbedtls_ecp_gen_key(MBEDTLS_ECP_DP_SECP256R1, &s_keypair, mbedtls_ctr_drbg_random, &ctr_drbg)) != 0) goto exit;
    if ((rc = mbedtls_mpi_write_binary(&s_keypair.private_d, priv, 32)) != 0) goto exit;
    if ((rc = mbedtls_ecp_point_write_binary(&s_keypair.private_grp, &s_keypair.private_Q,
        MBEDTLS_ECP_PF_UNCOMPRESSED, &olen, pub_bin, sizeof(pub_bin))) != 0) goto exit;
    
    memcpy(pub, &pub_bin[1], 64);
    
exit:
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    if (rc != 0) mbedtls_ecp_keypair_free(&s_keypair);
    
    return rc;
}

int ble_sm_alg_gen_dhkey(const uint8_t *peer_pub_key_x, const uint8_t *peer_pub_key_y, const uint8_t *our_priv_key, uint8_t *out_dhkey) {
    uint8_t dh[32];
    uint8_t pk[64];
    uint8_t priv[32];
    int rc = BLE_HS_EUNKNOWN;
    mbedtls_ecp_point pt;
    mbedtls_ecp_point_init(&pt);
    mbedtls_ecp_point Q;
    mbedtls_ecp_point_init(&Q);
    mbedtls_mpi z;
    mbedtls_mpi_init(&z);
    mbedtls_mpi d;
    mbedtls_mpi_init(&d);
    mbedtls_entropy_context entropy;
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ctr_drbg_init(&ctr_drbg);
    uint8_t pub[65] = {0};
    
    swap_buf(pk, peer_pub_key_x, 32);
    swap_buf(&pk[32], peer_pub_key_y, 32);
    swap_buf(priv, our_priv_key, 32);
    
    pub[0] = 0x04; // uncompressed
    memcpy(&pub[1], pk, 64);
    
    if (mbedtls_ecp_group_load(&s_keypair.private_grp, MBEDTLS_ECP_DP_SECP256R1) != 0) goto exit;
    if (mbedtls_ecp_point_read_binary(&s_keypair.private_grp, &pt, pub, 65) != 0) goto exit;
    if (mbedtls_ecp_check_pubkey(&s_keypair.private_grp, &pt) != 0) goto exit;
    if ((rc = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0)) != 0) goto exit;
    if (mbedtls_ecp_point_read_binary(&s_keypair.private_grp, &Q, pub, 65) != 0) goto exit;
    if (mbedtls_mpi_read_binary(&d, priv, 32) != 0) goto exit;
    
    rc = mbedtls_ecdh_compute_shared(&s_keypair.private_grp, &z, &Q, &d, mbedtls_ctr_drbg_random, &ctr_drbg);
    if (rc != 0) goto exit;
    
    rc = mbedtls_mpi_write_binary(&z, dh, 32);
    
exit:
    mbedtls_ecp_point_free(&pt);
    mbedtls_ecp_point_free(&Q);
    mbedtls_mpi_free(&z);
    mbedtls_mpi_free(&d);
    mbedtls_entropy_free(&entropy);
    mbedtls_ctr_drbg_free(&ctr_drbg);
    
    if (rc != 0) {
        return BLE_HS_EUNKNOWN;
    }
    
    swap_buf(out_dhkey, dh, 32);
    return 0;
}

// COMPLETE AND CORRECTED c1() implementation
// BLE Spec Part H, Section 2.2.4
// c1(k, r, preq, pres, iat, rat, ia, ra) = e(k, r XOR p1) XOR p2
// where:
//   p1 = pres || preq || rat || iat
//   p2 = ia || ra || 0x00000000
int ble_sm_alg_c1(const uint8_t *tk, const uint8_t *r,
                  const uint8_t *preq, const uint8_t *pres,
                  uint8_t iat, uint8_t rat,
                  const uint8_t *ia, const uint8_t *ra,
                  uint8_t *out_confirm)
{
    // FORCE ALIGNMENT
    uint8_t p1[16] __attribute__((aligned(4)));
    uint8_t p2[16] __attribute__((aligned(4)));
    uint8_t r_xor_p1[16] __attribute__((aligned(4)));
    uint8_t temp[16] __attribute__((aligned(4)));

    if (!tk || !r || !preq || !pres || !ia || !ra || !out_confirm) {
        return -1;
    }

    // 1. Construct p1 = pres || preq || rat || iat
    // LSB is pres[0], MSB is iat
/*    memcpy(p1, pres, 7);
    memcpy(p1 + 7, preq, 7);
    p1[14] = rat;
    p1[15] = iat;*/
    p1[0] = iat;              // LSB (Offset 0)
    p1[1] = rat;              // (Offset 1)
    memcpy(p1 + 2, preq, 7);  // (Offsets 2-8)
    memcpy(p1 + 9, pres, 7);  // MSB (Offsets 9-15)

    // 2. XOR r with p1
    for (int i = 0; i < 16; i++) {
        r_xor_p1[i] = r[i] ^ p1[i];
    }

    // 3. e(k, r XOR p1)
    int rc = ble_sm_alg_encrypt(tk, r_xor_p1, temp);
    if (rc != 0) return rc;

    // 4. Construct p2 = ra || ia || padding
    // LSB is ra[0], MSB is padding
	memcpy(p2, ra, 6);      // Responder Address (R_Address)
	memcpy(p2 + 6, ia, 6);  // Initiator Address (I_Address)
	memset(p2 + 12, 0, 4);


    // 5. XOR temp with p2
    for (int i = 0; i < 16; i++) {
        temp[i] ^= p2[i];
    }

    // 6. e(k, temp)
    rc = ble_sm_alg_encrypt(tk, temp, out_confirm);
    
    return rc;
}
