#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "lwip/err.h"
#include "lwip/sys.h"
static const char *TAG = "minimal-iot";
static int client_count = 0;
static void wifi_event_handler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_AP_STACONNECTED) {
        client_count++;
        ESP_LOGI(TAG, "Client connected, total=%d", client_count);
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        client_count--;
        ESP_LOGI(TAG, "Client disconnected, total=%d", client_count);
    }
}
static void wifi_init_softap(void) {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_ap();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL));
    wifi_config_t wifi_config = {.ap = {.ssid = "IoT-Minimal", .ssid_len = strlen("IoT-Minimal"), .channel = 1, .password = "", .max_connection = 1, .authmode = WIFI_AUTH_OPEN},};
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG, "SoftAP started: SSID=IoT-Minimal, IP=192.168.4.1");
}
extern void ble_main(void);
static void ble_task(void *arg) { ble_main(); vTaskDelete(NULL); }
void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    ESP_LOGI(TAG, "Starting minimal IoT PoC...");
    wifi_init_softap();
    xTaskCreate(ble_task, "ble_scan", 8192, NULL, 1, NULL);
    while (1) {
        if (client_count > 0) ESP_LOGI(TAG, "Active clients: %d", client_count);
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}
