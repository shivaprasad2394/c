#ifndef BLE_HOOKS_H
#define BLE_HOOKS_H

void ble_main(void);

#endif
