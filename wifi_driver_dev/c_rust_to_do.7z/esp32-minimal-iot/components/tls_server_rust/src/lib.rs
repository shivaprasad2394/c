#![no_std]
const JSON: &str = r#"{"status":"connected","uptime":123,"device":"ESP32-C3","version":"0.1.0"}"#;
#[no_mangle]
pub extern "C" fn get_json_response_ptr() -> *const u8 { JSON.as_ptr() }
#[no_mangle]
pub extern "C" fn get_json_response_len() -> usize { JSON.len() }
#[no_mangle]
pub extern "C" fn init_tls_server() -> i32 { 0 }
use core::panic::PanicInfo;
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! { loop {} }
