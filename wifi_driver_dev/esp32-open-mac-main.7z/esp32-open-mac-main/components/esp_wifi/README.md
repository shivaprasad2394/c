# Stripped down esp_wifi

This is a stripped down version of the esp_wifi component that only contains libpp.a for the esp32.