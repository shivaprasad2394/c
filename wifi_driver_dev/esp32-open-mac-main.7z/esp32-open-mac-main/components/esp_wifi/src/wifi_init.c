int wifi_log() {
    return 0;
};