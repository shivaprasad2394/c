// 80211_mac.c - C implementation of the 802.11 MAC layer
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
#include "80211_mac_interface.h"

// ============================================================================
// CONSTANTS AND CONFIGURATION
// ============================================================================

#define NETWORK_TO_CONNECT_SSID "meshtest"
#define SSID_TO_BROADCAST "esp32-ap"
#define INTERFACE_STA 0
#define INTERFACE_AP 1

#define AUTHENTICATE_INTERVAL_US (500 * 1000)
#define ASSOCIATE_INTERVAL_US (500 * 1000)
#define BEACON_INTERVAL_US (1024 * 100)  // 102.4 ms
#define CHANNEL_HOPPING_INTERVAL_US (1500 * 1000)

#define SEQNO_WINDOW_SIZE 32

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

// MAC Address structure
typedef struct {
    uint8_t addr[6];
} MACAddress;

static const MACAddress BROADCAST = {{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};
static const MACAddress ZERO = {{0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};

// State machine states for STA
typedef enum {
    STA_STATE_SCANNING,
    STA_STATE_AUTHENTICATE,
    STA_STATE_ASSOCIATE,
    STA_STATE_ASSOCIATED
} StaMachineStateType;

typedef struct {
    int64_t last_channel_change;
    bool has_last_channel_change;
} ScanningState;

typedef struct {
    int64_t last_sent;
    bool has_last_sent;
} AuthenticateState;

typedef struct {
    int64_t last_sent;
    bool has_last_sent;
} AssociateState;

typedef struct {
    StaMachineStateType type;
    union {
        ScanningState scanning;
        AuthenticateState authenticate;
        AssociateState associate;
    } state;
} StaMachineState;

// AP Client states
typedef enum {
    AP_CLIENT_DISCONNECTED,
    AP_CLIENT_AUTHENTICATED,
    AP_CLIENT_ASSOCIATED
} APClientStateType;

typedef struct {
    MACAddress addr;
    int64_t last_received_timestamp;
    APClientStateType state_type;
    uint16_t association_id;  // Only valid when state == ASSOCIATED
} APClient;

typedef struct {
    APClient clients[2];
    int64_t last_beacon_timestamp;
    bool has_last_beacon_timestamp;
} ApMachineState;

// Sequence control tracker
typedef struct {
    uint32_t sequence_control_bitmap;
    int32_t sequence_control_last_seqno;
    MACAddress mac_address;
} SequenceControlTracker;

// Global state
typedef struct {
    MACAddress iface_1_mac;
    MACAddress iface_2_mac;
    MACAddress bssid;
    StaMachineState sta_state;
    ApMachineState ap_state;
    uint8_t current_channel;
    SequenceControlTracker seq_control_trackers[1];
} GlobalState;

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

static bool mac_addr_equal(const MACAddress* a, const MACAddress* b) {
    return memcmp(a->addr, b->addr, 6) == 0;
}

static void mac_addr_copy(MACAddress* dst, const MACAddress* src) {
    memcpy(dst->addr, src->addr, 6);
}

static void print_mac_addr(const MACAddress* mac) {
    printf("%02x:%02x:%02x:%02x:%02x:%02x", 
           mac->addr[0], mac->addr[1], mac->addr[2],
           mac->addr[3], mac->addr[4], mac->addr[5]);
}

static uint8_t next_channel(uint8_t channel) {
    if (channel < 12) {
        return channel + 1;
    }
    return 1;
}

// ============================================================================
// FRAME CONSTRUCTION HELPERS
// ============================================================================

// These functions would need to construct actual 802.11 frames
// For brevity, I'm showing the structure - you'd need to implement full frame building

static int build_authentication_frame(uint8_t* buffer, size_t buf_size,
                                      const MACAddress* receiver,
                                      const MACAddress* transmitter,
                                      const MACAddress* bssid,
                                      uint16_t auth_alg,
                                      uint16_t auth_seq,
                                      uint16_t status_code) {
    // Frame Control Field (2 bytes)
    buffer[0] = 0xB0;  // Authentication frame, management type
    buffer[1] = 0x00;
    
    // Duration (2 bytes)
    buffer[2] = 0x00;
    buffer[3] = 0x00;
    
    // Receiver address
    memcpy(&buffer[4], receiver->addr, 6);
    
    // Transmitter address
    memcpy(&buffer[10], transmitter->addr, 6);
    
    // BSSID
    memcpy(&buffer[16], bssid->addr, 6);
    
    // Sequence control (2 bytes) - simplified
    buffer[22] = 0x00;
    buffer[23] = 0x00;
    
    // Authentication body
    int offset = 24;
    
    // Algorithm number
    buffer[offset++] = auth_alg & 0xFF;
    buffer[offset++] = (auth_alg >> 8) & 0xFF;
    
    // Transaction sequence number
    buffer[offset++] = auth_seq & 0xFF;
    buffer[offset++] = (auth_seq >> 8) & 0xFF;
    
    // Status code
    buffer[offset++] = status_code & 0xFF;
    buffer[offset++] = (status_code >> 8) & 0xFF;
    
    return offset;
}

static int build_association_request(uint8_t* buffer, size_t buf_size,
                                     const MACAddress* receiver,
                                     const MACAddress* transmitter,
                                     const MACAddress* bssid,
                                     const char* ssid) {
    // Frame Control Field
    buffer[0] = 0x00;  // Association request
    buffer[1] = 0x00;
    
    // Duration
    buffer[2] = 0x00;
    buffer[3] = 0x00;
    
    // Addresses
    memcpy(&buffer[4], receiver->addr, 6);
    memcpy(&buffer[10], transmitter->addr, 6);
    memcpy(&buffer[16], bssid->addr, 6);
    
    // Sequence control
    buffer[22] = 0x00;
    buffer[23] = 0x00;
    
    int offset = 24;
    
    // Capability information (2 bytes)
    buffer[offset++] = 0x01;  // ESS
    buffer[offset++] = 0x00;
    
    // Listen interval (2 bytes)
    buffer[offset++] = 0x00;
    buffer[offset++] = 0x00;
    
    // SSID element
    buffer[offset++] = 0x00;  // Element ID for SSID
    int ssid_len = strlen(ssid);
    buffer[offset++] = ssid_len;
    memcpy(&buffer[offset], ssid, ssid_len);
    offset += ssid_len;
    
    // Supported rates
    buffer[offset++] = 0x01;  // Element ID for supported rates
    buffer[offset++] = 2;     // Length
    buffer[offset++] = 0x82;  // 1 Mbps (basic)
    buffer[offset++] = 0x84;  // 2 Mbps (basic)
    
    return offset;
}

static int build_beacon_frame(uint8_t* buffer, size_t buf_size,
                              const MACAddress* bssid,
                              const char* ssid,
                              uint8_t channel) {
    // Frame Control Field
    buffer[0] = 0x80;  // Beacon frame
    buffer[1] = 0x00;
    
    // Duration
    buffer[2] = 0x00;
    buffer[3] = 0x00;
    
    // Destination (broadcast)
    memcpy(&buffer[4], BROADCAST.addr, 6);
    
    // Source (BSSID)
    memcpy(&buffer[10], bssid->addr, 6);
    
    // BSSID
    memcpy(&buffer[16], bssid->addr, 6);
    
    // Sequence control
    buffer[22] = 0x00;
    buffer[23] = 0x00;
    
    int offset = 24;
    
    // Timestamp (8 bytes) - will be overwritten by hardware
    memset(&buffer[offset], 0, 8);
    offset += 8;
    
    // Beacon interval (2 bytes) - 100 TUs
    buffer[offset++] = 0x64;
    buffer[offset++] = 0x00;
    
    // Capability information
    buffer[offset++] = 0x01;  // ESS
    buffer[offset++] = 0x00;
    
    // SSID element
    buffer[offset++] = 0x00;
    int ssid_len = strlen(ssid);
    buffer[offset++] = ssid_len;
    memcpy(&buffer[offset], ssid, ssid_len);
    offset += ssid_len;
    
    // Supported rates
    buffer[offset++] = 0x01;
    buffer[offset++] = 8;
    buffer[offset++] = 0x82;  // 1 Mbps (B)
    buffer[offset++] = 0x84;  // 2 Mbps (B)
    buffer[offset++] = 0x8B;  // 5.5 Mbps (B)
    buffer[offset++] = 0x96;  // 11 Mbps (B)
    buffer[offset++] = 0x0C;  // 6 Mbps
    buffer[offset++] = 0x12;  // 9 Mbps
    buffer[offset++] = 0x18;  // 12 Mbps
    buffer[offset++] = 0x24;  // 18 Mbps
    
    // DS Parameter Set
    buffer[offset++] = 0x03;
    buffer[offset++] = 0x01;
    buffer[offset++] = channel;
    
    // TIM element
    buffer[offset++] = 0x05;
    buffer[offset++] = 0x04;
    buffer[offset++] = 0x01;  // DTIM count
    buffer[offset++] = 0x02;  // DTIM period
    buffer[offset++] = 0x00;  // Bitmap control
    buffer[offset++] = 0xFA;  // Partial virtual bitmap
    
    return offset;
}

static int build_data_frame(uint8_t* buffer, size_t buf_size,
                           const MACAddress* addr1,
                           const MACAddress* addr2,
                           const MACAddress* addr3,
                           bool to_ds, bool from_ds,
                           uint16_t ether_type,
                           const uint8_t* payload, size_t payload_len) {
    // Frame Control
    uint8_t fcf = 0x08;  // Data frame
    if (to_ds) fcf |= 0x01;
    if (from_ds) fcf |= 0x02;
    
    buffer[0] = fcf;
    buffer[1] = 0x00;
    
    // Duration
    buffer[2] = 0x00;
    buffer[3] = 0x00;
    
    // Addresses
    memcpy(&buffer[4], addr1->addr, 6);
    memcpy(&buffer[10], addr2->addr, 6);
    memcpy(&buffer[16], addr3->addr, 6);
    
    // Sequence control
    buffer[22] = 0x10;  // Fragment 1
    buffer[23] = 0x00;  // Sequence 1
    
    int offset = 24;
    
    // LLC/SNAP header
    buffer[offset++] = 0xAA;  // DSAP
    buffer[offset++] = 0xAA;  // SSAP
    buffer[offset++] = 0x03;  // Control
    buffer[offset++] = 0x00;  // OUI
    buffer[offset++] = 0x00;
    buffer[offset++] = 0x00;
    
    // EtherType
    buffer[offset++] = (ether_type >> 8) & 0xFF;
    buffer[offset++] = ether_type & 0xFF;
    
    // Payload
    memcpy(&buffer[offset], payload, payload_len);
    offset += payload_len;
    
    return offset;
}

// ============================================================================
// TRANSMIT FUNCTIONS
// ============================================================================

static bool transmit_frame(const uint8_t* frame_data, size_t frame_len, uint32_t rate) {
    rs_smart_frame_t* smart_frame = rs_get_smart_frame(frame_len);
    if (!smart_frame) {
        return false;
    }
    
    smart_frame->payload_length = frame_len;
    smart_frame->rate = rate;
    memcpy(smart_frame->payload, frame_data, frame_len);
    
    rs_tx_smart_frame(smart_frame);
    return true;
}

// ============================================================================
// STATE TRANSITION FUNCTIONS
// ============================================================================

static void transition_to_scanning(GlobalState* state) {
    printf("Transitioning to scanning\n");
    
    rs_mark_iface_down(STA_1_MAC_INTERFACE_TYPE);
    rs_filters_set_scanning(INTERFACE_STA, state->iface_1_mac.addr);
    
    state->sta_state.type = STA_STATE_SCANNING;
    state->sta_state.state.scanning.has_last_channel_change = false;
}

static void transition_to_authenticating(GlobalState* state, 
                                        const MACAddress* bssid, 
                                        uint8_t channel) {
    printf("Transitioning to authenticating\n");
    
    rs_filters_set_client_with_bssid(INTERFACE_STA, 
                                     state->iface_1_mac.addr, 
                                     bssid->addr);
    
    mac_addr_copy(&state->bssid, bssid);
    state->sta_state.type = STA_STATE_AUTHENTICATE;
    state->sta_state.state.authenticate.has_last_sent = false;
}

// ============================================================================
// FRAME HANDLERS - STA MODE
// ============================================================================

static void handle_sta_beacon(GlobalState* state, const uint8_t* frame, 
                              size_t frame_len, uint8_t channel) {
    // Parse beacon frame
    // Simplified - you'd need full 802.11 parsing here
    
    // Look for SSID element
    int offset = 24 + 12;  // Skip MAC header + fixed beacon fields
    
    while (offset + 2 < frame_len) {
        uint8_t element_id = frame[offset];
        uint8_t element_len = frame[offset + 1];
        
        if (element_id == 0) {  // SSID
            if (element_len == strlen(NETWORK_TO_CONNECT_SSID) &&
                memcmp(&frame[offset + 2], NETWORK_TO_CONNECT_SSID, element_len) == 0) {
                
                // Check if it's an open network (no RSN element)
                bool has_rsn = false;
                int check_offset = offset + 2 + element_len;
                while (check_offset + 2 < frame_len) {
                    if (frame[check_offset] == 48) {  // RSN element
                        has_rsn = true;
                        break;
                    }
                    check_offset += 2 + frame[check_offset + 1];
                }
                
                if (!has_rsn && state->sta_state.type == STA_STATE_SCANNING) {
                    printf("Found matching open network, authenticating\n");
                    MACAddress bssid;
                    memcpy(bssid.addr, &frame[16], 6);  // BSSID from frame
                    transition_to_authenticating(state, &bssid, channel);
                }
                return;
            }
        }
        
        offset += 2 + element_len;
    }
}

static void handle_sta_authentication(GlobalState* state, const uint8_t* frame, 
                                      size_t frame_len) {
    // Parse authentication frame
    int offset = 24;  // Skip MAC header
    
    uint16_t auth_alg = frame[offset] | (frame[offset + 1] << 8);
    uint16_t status_code = frame[offset + 4] | (frame[offset + 5] << 8);
    
    if (auth_alg == 0 && status_code == 0) {  // Open system, success
        printf("Authentication successful, transitioning to associate\n");
        state->sta_state.type = STA_STATE_ASSOCIATE;
        state->sta_state.state.associate.has_last_sent = false;
    }
}

static void handle_sta_association_response(GlobalState* state, const uint8_t* frame,
                                            size_t frame_len) {
    int offset = 24;  // Skip MAC header
    
    // Capability info (2) + Status (2) + AID (2)
    uint16_t status_code = frame[offset + 2] | (frame[offset + 3] << 8);
    
    if (status_code == 0) {  // Success
        printf("Association successful!\n");
        if (state->sta_state.type != STA_STATE_ASSOCIATED) {
            rs_mark_iface_up(STA_1_MAC_INTERFACE_TYPE);
        }
        state->sta_state.type = STA_STATE_ASSOCIATED;
        mac_addr_copy(&state->seq_control_trackers[0].mac_address, &state->bssid);
    }
}

static void handle_sta_disassociation(GlobalState* state, const uint8_t* frame,
                                      size_t frame_len) {
    if (state->sta_state.type != STA_STATE_SCANNING) {
        printf("Disassociated, returning to scanning\n");
        transition_to_scanning(state);
    }
}

static void handle_sta_deauthentication(GlobalState* state, const uint8_t* frame,
                                       size_t frame_len) {
    if (state->sta_state.type != STA_STATE_SCANNING) {
        printf("Deauthenticated, returning to scanning\n");
        transition_to_scanning(state);
    }
}

static void handle_sta_data_frame(GlobalState* state, const uint8_t* frame,
                                 size_t frame_len) {
    // Parse data frame - extract LLC/SNAP payload
    uint8_t fcf = frame[0];
    bool to_ds = (fcf & 0x01) != 0;
    bool from_ds = (fcf & 0x02) != 0;
    
    if (from_ds && !to_ds) {  // Frame from DS
        MACAddress destination, source;
        memcpy(destination.addr, &frame[4], 6);   // Address 1 (DA)
        memcpy(source.addr, &frame[16], 6);       // Address 3 (SA)
        
        int offset = 24;  // Skip MAC header
        
        // Check for LLC/SNAP header
        if (frame[offset] == 0xAA && frame[offset + 1] == 0xAA) {
            offset += 6;  // Skip LLC/SNAP to EtherType
            
            uint16_t ether_type = (frame[offset] << 8) | frame[offset + 1];
            offset += 2;
            
            const uint8_t* payload = &frame[offset];
            size_t payload_len = frame_len - offset;
            
            // Build Ethernet frame and pass to network stack
            size_t eth_frame_len = 6 + 6 + 2 + payload_len;
            uint8_t* eth_buffer = rs_get_mac_rx_frame(eth_frame_len);
            
            if (eth_buffer) {
                memcpy(&eth_buffer[0], destination.addr, 6);
                memcpy(&eth_buffer[6], source.addr, 6);
                eth_buffer[12] = (ether_type >> 8) & 0xFF;
                eth_buffer[13] = ether_type & 0xFF;
                memcpy(&eth_buffer[14], payload, payload_len);
                
                rs_rx_mac_frame(STA_1_MAC_INTERFACE_TYPE, eth_buffer, eth_frame_len);
            }
        }
    }
}

// ============================================================================
// FRAME HANDLERS - AP MODE
// ============================================================================

static void handle_ap_probe_request(GlobalState* state, const uint8_t* frame,
                                   size_t frame_len) {
    // Parse probe request and send response
    // This is simplified - full implementation would parse elements
    
    uint8_t response_buf[512];
    int response_len = build_beacon_frame(response_buf, sizeof(response_buf),
                                         &state->iface_2_mac,
                                         SSID_TO_BROADCAST,
                                         state->current_channel);
    
    // Modify frame type to probe response
    response_buf[0] = 0x50;
    
    // Set destination to requester
    memcpy(&response_buf[4], &frame[10], 6);  // Copy transmitter addr
    
    transmit_frame(response_buf, response_len, 0);
}

static void handle_ap_authentication(GlobalState* state, const uint8_t* frame,
                                    size_t frame_len) {
    int offset = 24;
    uint16_t auth_alg = frame[offset] | (frame[offset + 1] << 8);
    uint16_t auth_seq = frame[offset + 2] | (frame[offset + 3] << 8);
    uint16_t status = frame[offset + 4] | (frame[offset + 5] << 8);
    
    if (auth_alg == 0 && auth_seq == 1 && status == 0) {  // Open system, seq 1
        MACAddress client_addr;
        memcpy(client_addr.addr, &frame[10], 6);  // Transmitter address
        
        uint8_t response_buf[128];
        int response_len = build_authentication_frame(response_buf, sizeof(response_buf),
                                                     &client_addr,
                                                     &state->iface_2_mac,
                                                     &state->iface_2_mac,
                                                     0,  // Open system
                                                     2,  // Sequence 2
                                                     0); // Success
        
        transmit_frame(response_buf, response_len, 0);
    }
}

static void handle_ap_association_request(GlobalState* state, const uint8_t* frame,
                                         size_t frame_len) {
    MACAddress client_addr;
    memcpy(client_addr.addr, &frame[10], 6);  // Transmitter address
    
    // Find free association ID
    uint16_t association_id = 1;
    for (int potential_aid = 1; potential_aid <= 2007; potential_aid++) {
        bool in_use = false;
        for (int i = 0; i < 2; i++) {
            if (state->ap_state.clients[i].state_type == AP_CLIENT_ASSOCIATED &&
                state->ap_state.clients[i].association_id == potential_aid) {
                in_use = true;
                break;
            }
        }
        if (!in_use) {
            association_id = potential_aid;
            break;
        }
    }
    
    // Store client
    for (int i = 0; i < 2; i++) {
        if (state->ap_state.clients[i].state_type != AP_CLIENT_ASSOCIATED) {
            state->ap_state.clients[i].state_type = AP_CLIENT_ASSOCIATED;
            state->ap_state.clients[i].association_id = association_id;
            mac_addr_copy(&state->ap_state.clients[i].addr, &client_addr);
            state->ap_state.clients[i].last_received_timestamp = rs_get_time_us();
            
            printf("Client associated with AID %d: ", association_id);
            print_mac_addr(&client_addr);
            printf("\n");
            break;
        }
    }
    
    // Build association response
    uint8_t response_buf[256];
    int offset = 0;
    
    // Frame control
    response_buf[offset++] = 0x10;  // Association response
    response_buf[offset++] = 0x00;
    
    // Duration
    response_buf[offset++] = 0x00;
    response_buf[offset++] = 0x00;
    
    // Addresses
    memcpy(&response_buf[offset], client_addr.addr, 6);
    offset += 6;
    memcpy(&response_buf[offset], state->iface_2_mac.addr, 6);
    offset += 6;
    memcpy(&response_buf[offset], state->iface_2_mac.addr, 6);
    offset += 6;
    
    // Sequence control
    response_buf[offset++] = 0x00;
    response_buf[offset++] = 0x00;
    
    // Capability info
    response_buf[offset++] = 0x01;
    response_buf[offset++] = 0x00;
    
    // Status code
    response_buf[offset++] = 0x00;
    response_buf[offset++] = 0x00;
    
    // AID
    response_buf[offset++] = association_id & 0xFF;
    response_buf[offset++] = (association_id >> 8) & 0xFF;
    
    // Supported rates
    response_buf[offset++] = 0x01;
    response_buf[offset++] = 8;
    response_buf[offset++] = 0x82;
    response_buf[offset++] = 0x84;
    response_buf[offset++] = 0x8B;
    response_buf[offset++] = 0x96;
    response_buf[offset++] = 0x0C;
    response_buf[offset++] = 0x12;
    response_buf[offset++] = 0x18;
    response_buf[offset++] = 0x24;
    
    transmit_frame(response_buf, offset, 0);
}

static void handle_ap_data_frame(GlobalState* state, const uint8_t* frame,
                                size_t frame_len) {
    // Update client timestamp
    MACAddress destination;
    memcpy(destination.addr, &frame[4], 6);  // Address 1
    
    for (int i = 0; i < 2; i++) {
        if (mac_addr_equal(&state->ap_state.clients[i].addr, &destination)) {
            state->ap_state.clients[i].last_received_timestamp = rs_get_time_us();
        }
    }
    
    // Parse and forward to network stack (similar to STA)
    uint8_t fcf = frame[0];
    bool to_ds = (fcf & 0x01) != 0;
    bool from_ds = (fcf & 0x02) != 0;
    
    if (to_ds && !from_ds) {  // Frame to DS
        MACAddress source;
        memcpy(destination.addr, &frame[16], 6);  // Address 3 (DA)
        memcpy(source.addr, &frame[10], 6);       // Address 2 (SA)
        
        int offset = 24;
        
        if (frame[offset] == 0xAA && frame[offset + 1] == 0xAA) {
            offset += 6;
            uint16_t ether_type = (frame[offset] << 8) | frame[offset + 1];
            offset += 2;
            
            const uint8_t* payload = &frame[offset];
            size_t payload_len = frame_len - offset;
            
            size_t eth_frame_len = 6 + 6 + 2 + payload_len;
            uint8_t* eth_buffer = rs_get_mac_rx_frame(eth_frame_len);
            
            if (eth_buffer) {
                memcpy(&eth_buffer[0], destination.addr, 6);
                memcpy(&eth_buffer[6], source.addr, 6);
                eth_buffer[12] = (ether_type >> 8) & 0xFF;
                eth_buffer[13] = ether_type & 0xFF;
                memcpy(&eth_buffer[14], payload, payload_len);
                
                rs_rx_mac_frame(AP_2_MAC_INTERFACE_TYPE, eth_buffer, eth_frame_len);
            }
        }
    }
}

// ============================================================================
// TX FROM MAC LAYER
// ============================================================================

static void send_authenticate(GlobalState* state) {
    uint8_t frame_buf[128];
    int frame_len = build_authentication_frame(frame_buf, sizeof(frame_buf),
                                              &state->bssid,
                                              &state->iface_1_mac,
                                              &state->bssid,
                                              0,  // Open system
                                              1,  // Sequence 1
                                              0); // Success
    
    transmit_frame(frame_buf, frame_len, 0x18);
    
    if (state->sta_state.type == STA_STATE_AUTHENTICATE) {
        state->sta_state.state.authenticate.last_sent = rs_get_time_us();
        state->sta_state.state.authenticate.has_last_sent = true;
    }
}

static void send_associate(GlobalState* state) {
    uint8_t frame_buf[256];
    int frame_len = build_association_request(frame_buf, sizeof(frame_buf),
                                             &state->bssid,
                                             &state->iface_1_mac,
                                             &state->bssid,
                                             NETWORK_TO_CONNECT_SSID);
    
    transmit_frame(frame_buf, frame_len, 12);
    
    if (state->sta_state.type == STA_STATE_ASSOCIATE) {
        state->sta_state.state.associate.last_sent = rs_get_time_us();
        state->sta_state.state.associate.has_last_sent = true;
    }
}

static void send_sta_data_frame(GlobalState* state, uint8_t* eth_frame, size_t eth_len) {
    // Extract Ethernet header fields
    MACAddress dest, src;
    memcpy(dest.addr, &eth_frame[0], 6);
    memcpy(src.addr, &eth_frame[6], 6);
    uint16_t ether_type = (eth_frame[12] << 8) | eth_frame[13];
    
    uint8_t* payload = &eth_frame[14];
    size_t payload_len = eth_len - 14;
    
    uint8_t frame_buf[2352];
    int frame_len = build_data_frame(frame_buf, sizeof(frame_buf),
                                    &state->bssid,        // Address 1 (RA = BSSID)
                                    &state->iface_1_mac,  // Address 2 (TA)
                                    &dest,                // Address 3 (DA)
                                    true, false,          // to_ds=true, from_ds=false
                                    ether_type,
                                    payload, payload_len);
    
    transmit_frame(frame_buf, frame_len, 12);
}

static void send_ap_data_frame(GlobalState* state, uint8_t* eth_frame, size_t eth_len) {
    MACAddress dest, src;
    memcpy(dest.addr, &eth_frame[0], 6);
    memcpy(src.addr, &eth_frame[6], 6);
    uint16_t ether_type = (eth_frame[12] << 8) | eth_frame[13];
    
    uint8_t* payload = &eth_frame[14];
    size_t payload_len = eth_len - 14;
    
    uint8_t frame_buf[2352];
    int frame_len = build_data_frame(frame_buf, sizeof(frame_buf),
                                    &dest,                // Address 1 (RA)
                                    &state->iface_2_mac,  // Address 2 (TA = BSSID)
                                    &src,                 // Address 3 (SA)
                                    false, true,          // to_ds=false, from_ds=true
                                    ether_type,
                                    payload, payload_len);
    
    transmit_frame(frame_buf, frame_len, 12);
}

// ============================================================================
// SEQUENCE CONTROL
// ============================================================================

static bool sequence_control_accept(GlobalState* state, uint16_t seq_ctrl,
                                    const MACAddress* transmitter,
                                    const MACAddress* receiver) {
    // Check if frame is for us
    if (!mac_addr_equal(&state->iface_1_mac, receiver) &&
        !mac_addr_equal(&state->iface_2_mac, receiver)) {
        printf("Accepting likely broadcast frame\n");
        return true;
    }
    
    uint16_t seq_num = (seq_ctrl >> 4) & 0xFFF;
    
    for (int i = 0; i < 1; i++) {
        if (!mac_addr_equal(&state->seq_control_trackers[i].mac_address, transmitter)) {
            continue;
        }
        
        int32_t seqno_diff = (int32_t)seq_num - state->seq_control_trackers[i].sequence_control_last_seqno;
        
        printf("Sequence number = %ld, last = %ld, diff = %ld\n",(long)seq_num, (long)state->seq_control_trackers[i].sequence_control_last_seqno, (long)seqno_diff);
        
        if (seqno_diff <= 0 && seqno_diff > -SEQNO_WINDOW_SIZE) {
            // Inside window, slightly older
            if ((state->seq_control_trackers[i].sequence_control_bitmap & (1 << -seqno_diff)) != 0) {
                return false;  // Duplicate
            }
            state->seq_control_trackers[i].sequence_control_bitmap |= (1 << -seqno_diff);
            return true;
        } else if (seqno_diff > 0 && seqno_diff < SEQNO_WINDOW_SIZE) {
            // Slightly newer
            state->seq_control_trackers[i].sequence_control_bitmap <<= seqno_diff;
            state->seq_control_trackers[i].sequence_control_bitmap |= 1;
            state->seq_control_trackers[i].sequence_control_last_seqno = seq_num;
            return true;
        } else if (seqno_diff >= SEQNO_WINDOW_SIZE && seqno_diff < 4095) {
            // Much newer
            printf("Missed a lot of packets (%ld)\n",(long) seqno_diff - 1);
            state->seq_control_trackers[i].sequence_control_bitmap = 1;
            state->seq_control_trackers[i].sequence_control_last_seqno = seq_num;
            return true;
        } else {
            // Other host may have restarted
            printf("Other host may have restarted\n");
            state->seq_control_trackers[i].sequence_control_bitmap = 1;
            state->seq_control_trackers[i].sequence_control_last_seqno = seq_num;
            return true;
        }
    }
    
    return true;
}

// ============================================================================
// STATE HANDLING
// ============================================================================

static uint32_t handle_state_sta(GlobalState* state) {
    switch (state->sta_state.type) {
        case STA_STATE_SCANNING: {
            if (!state->sta_state.state.scanning.has_last_channel_change) {
                printf("Setting last channel change to now\n");
                state->sta_state.state.scanning.last_channel_change = rs_get_time_us();
                state->sta_state.state.scanning.has_last_channel_change = true;
            }
            
            int64_t now = rs_get_time_us();
            int64_t us_to_wait = (state->sta_state.state.scanning.last_channel_change + 
                                 CHANNEL_HOPPING_INTERVAL_US) - now;
            
            if (us_to_wait <= 0) {
                state->current_channel = next_channel(state->current_channel);
                rs_change_channel(state->current_channel);
                state->sta_state.state.scanning.last_channel_change = rs_get_time_us();
                return (CHANNEL_HOPPING_INTERVAL_US / 1000);
            } else {
                return (us_to_wait / 1000);
            }
        }
        
        case STA_STATE_AUTHENTICATE: {
            int64_t us_to_wait = 0;
            if (state->sta_state.state.authenticate.has_last_sent) {
                us_to_wait = (state->sta_state.state.authenticate.last_sent + 
                             AUTHENTICATE_INTERVAL_US) - rs_get_time_us();
            }
            
            if (us_to_wait <= 0) {
                send_authenticate(state);
                return (AUTHENTICATE_INTERVAL_US / 1000);
            } else {
                return (us_to_wait / 1000);
            }
        }
        
        case STA_STATE_ASSOCIATE: {
            int64_t us_to_wait = 0;
            if (state->sta_state.state.associate.has_last_sent) {
                us_to_wait = (state->sta_state.state.associate.last_sent + 
                             ASSOCIATE_INTERVAL_US) - rs_get_time_us();
            }
            
            if (us_to_wait <= 0) {
                printf("Sending association request\n");
                send_associate(state);
                return (ASSOCIATE_INTERVAL_US / 1000);
            } else {
                return (us_to_wait / 1000);
            }
        }
        
        default:
            return 10000;
    }
}

static uint32_t handle_state_ap(GlobalState* state) {
    int64_t us_to_wait = 0;
    if (state->ap_state.has_last_beacon_timestamp) {
        us_to_wait = (state->ap_state.last_beacon_timestamp + 
                     BEACON_INTERVAL_US) - rs_get_time_us();
    }
    
    if (us_to_wait <= 0) {
        printf("Sending beacon\n");
        
        uint8_t beacon_buf[512];
        int beacon_len = build_beacon_frame(beacon_buf, sizeof(beacon_buf),
                                           &state->iface_2_mac,
                                           SSID_TO_BROADCAST,
                                           state->current_channel);
        
        transmit_frame(beacon_buf, beacon_len, 0);
        
        state->ap_state.last_beacon_timestamp = rs_get_time_us();
        state->ap_state.has_last_beacon_timestamp = true;
        
        return (BEACON_INTERVAL_US / 1000);
    } else {
        return (us_to_wait / 1000);
    }
}

// ============================================================================
// HARDWARE RX HANDLERS
// ============================================================================

static void handle_sta_hardware_rx(GlobalState* state, dma_list_item* dma_item) {
    wifi_promiscuous_pkt_openmac_t* packet = dma_item->packet;
    uint8_t* payload = packet->payload;
    size_t payload_len = packet->rx_ctrl.sig_len;
    
    if (payload_len < 24) {
        return;  // Too short
    }
    
    // Determine frame type
    uint8_t frame_type = (payload[0] >> 2) & 0x03;
    uint8_t frame_subtype = (payload[0] >> 4) & 0x0F;
    
    printf("STA RX: type=%d subtype=%d\n", frame_type, frame_subtype);
    
    // Extract sequence control and addresses for duplicate detection
    uint16_t seq_ctrl = payload[22] | (payload[23] << 8);
    MACAddress transmitter, receiver;
    memcpy(transmitter.addr, &payload[10], 6);
    memcpy(receiver.addr, &payload[4], 6);
    
    if (!sequence_control_accept(state, seq_ctrl, &transmitter, &receiver)) {
        printf("Duplicate frame detected!\n");
        return;
    }
    
    if (frame_type == 0) {  // Management
        switch (frame_subtype) {
            case 8:  // Beacon
                handle_sta_beacon(state, payload, payload_len, 
                                 packet->rx_ctrl.channel);
                break;
            case 11:  // Authentication
                handle_sta_authentication(state, payload, payload_len);
                break;
            case 1:   // Association response
                handle_sta_association_response(state, payload, payload_len);
                break;
            case 10:  // Disassociation
                handle_sta_disassociation(state, payload, payload_len);
                break;
            case 12:  // Deauthentication
                handle_sta_deauthentication(state, payload, payload_len);
                break;
        }
    } else if (frame_type == 2) {  // Data
        handle_sta_data_frame(state, payload, payload_len);
    }
}

static void handle_ap_hardware_rx(GlobalState* state, dma_list_item* dma_item) {
    wifi_promiscuous_pkt_openmac_t* packet = dma_item->packet;
    uint8_t* payload = packet->payload;
    size_t payload_len = packet->rx_ctrl.sig_len;
    
    if (payload_len < 24) {
        return;
    }
    
    uint8_t frame_type = (payload[0] >> 2) & 0x03;
    uint8_t frame_subtype = (payload[0] >> 4) & 0x0F;
    
    printf("AP RX: type=%d subtype=%d\n", frame_type, frame_subtype);
    
    if (frame_type == 0) {  // Management
        switch (frame_subtype) {
            case 4:   // Probe request
                handle_ap_probe_request(state, payload, payload_len);
                break;
            case 11:  // Authentication
                handle_ap_authentication(state, payload, payload_len);
                break;
            case 0:   // Association request
                handle_ap_association_request(state, payload, payload_len);
                break;
        }
    } else if (frame_type == 2) {  // Data
        handle_ap_data_frame(state, payload, payload_len);
    }
}

// ============================================================================
// MAIN MAC TASK
// ============================================================================

void rust_mac_task(void) {
    GlobalState state = {0};
    
    // Initialize MACs
    uint8_t mac1[] = {0x00, 0x23, 0x45, 0x67, 0x89, 0xAB};
    uint8_t mac2[] = {0x00, 0x20, 0x91, 0x00, 0x00, 0x00};
    memcpy(state.iface_1_mac.addr, mac1, 6);
    memcpy(state.iface_2_mac.addr, mac2, 6);
    
    mac_addr_copy(&state.bssid, &BROADCAST);
    state.current_channel = 1;
    
    // Initialize AP state
    for (int i = 0; i < 2; i++) {
        state.ap_state.clients[i].state_type = AP_CLIENT_DISCONNECTED;
        mac_addr_copy(&state.ap_state.clients[i].addr, &ZERO);
    }
    state.ap_state.has_last_beacon_timestamp = false;
    
    // Initialize sequence control
    state.seq_control_trackers[0].sequence_control_bitmap = 0;
    state.seq_control_trackers[0].sequence_control_last_seqno = 0;
    mac_addr_copy(&state.seq_control_trackers[0].mac_address, &ZERO);
    
    // Set AP mode
    rs_filters_set_ap_mode(1, state.iface_2_mac.addr);
    
    // Start in scanning mode
    transition_to_scanning(&state);
    
    uint32_t wait_for = 0;
    
    while (1) {
        rs_event_type_t event_type;
        void* ptr;
        size_t len;
        
        bool has_event = rs_get_next_mac_event_raw(wait_for, &event_type, &ptr, &len);
        
        if (has_event) {
            wait_for = 0;
            
            switch (event_type) {
                case EVENT_TYPE_PHY_RX_DATA: {
                    dma_list_item* dma_item = (dma_list_item*)ptr;
                    wifi_promiscuous_pkt_openmac_t* packet = dma_item->packet;
                    uint8_t filter_match = packet->rx_ctrl.filter_match;
                    
                    if (filter_match & 0x01) {  // STA interface
                        handle_sta_hardware_rx(&state, dma_item);
                    }
                    
                    if (filter_match & 0x02) {  // AP interface
                        handle_ap_hardware_rx(&state, dma_item);
                    }
                    
                    rs_recycle_dma_item(dma_item);
                    break;
                }
                
                case EVENT_TYPE_MAC_TX_DATA_FRAME: {
                    uint8_t* frame = (uint8_t*)ptr;
                    uint8_t interface = frame[0];
                    
                    printf("MAC TX: interface=%d\n", interface);
                    
                    if (interface == STA_1_MAC_INTERFACE_TYPE) {
                        if (state.sta_state.type == STA_STATE_ASSOCIATED) {
                            send_sta_data_frame(&state, &frame[1], len - 1);
                        } else {
                            printf("Dropping frame - not associated\n");
                        }
                    } else if (interface == AP_2_MAC_INTERFACE_TYPE) {
                        send_ap_data_frame(&state, &frame[1], len - 1);
                    }
                    
                    rs_recycle_mac_tx_data(frame);
                    break;
                }
                
                default:
                    break;
            }
        } else {
            // Timeout - handle state machine
            uint32_t wait_sta = handle_state_sta(&state);
            uint32_t wait_ap = handle_state_ap(&state);
            wait_for = (wait_sta < wait_ap) ? wait_sta : wait_ap;
        }
    }
}

