#pragma once

void hwinit();