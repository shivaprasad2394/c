// smp_crypto.c - Wrapper for SMP Just Works crypto operations

#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include "smp_crypto.h"

// Forward declarations from smp_crypto_alg.c
extern int ble_sm_alg_gen_key_pair(uint8_t *pub, uint8_t *priv);

extern int ble_sm_alg_f4(const uint8_t *u, const uint8_t *v, const uint8_t *x, 
                         uint8_t z, uint8_t *out_enc_data);
extern int ble_sm_alg_encrypt(const uint8_t *key, const uint8_t *plaintext, uint8_t *enc_data);

// Generate ephemeral ECDH keypair
int smp_crypto_gen_keypair(ble_sm_ecc_point_t *out_pub, ble_sm_ecc_secret_t *out_priv) {
    if (!out_pub || !out_priv) {
        return -1;
    }
    
    uint8_t pub[64];
    uint8_t priv[32];
    
    int ret = ble_sm_alg_gen_key_pair(pub, priv);
    if (ret != 0) {
        printf("[SMP-CRYPTO] Failed to generate keypair\n");
        return ret;
    }
    
    memcpy(out_pub->x, pub, 32);
    memcpy(out_pub->y, &pub[32], 32);
    memcpy(out_priv->data, priv, 32);
    
    printf("[SMP-CRYPTO] ✓ Generated ephemeral ECDH keypair\n");
    return 0;
}

// Compute DHKey
int smp_crypto_gen_dhkey(const ble_sm_ecc_point_t *peer_pub,
                         const ble_sm_ecc_secret_t *our_priv,
                         uint8_t *out_dhkey) {
    if (!peer_pub || !our_priv || !out_dhkey) {
        return -1;
    }
    
    int ret = ble_sm_alg_gen_dhkey(peer_pub->x, peer_pub->y, our_priv->data, out_dhkey);
    if (ret != 0) {
        printf("[SMP-CRYPTO] Failed to compute DHKey\n");
        return ret;
    }
    
    printf("[SMP-CRYPTO] ✓ Computed DHKey\n");
    return 0;
}

// Compute Confirm value (Just Works, z=0)
int smp_crypto_confirm(const uint8_t *tk,
                       const uint8_t *rand,
                       const uint8_t *peer_rand,
                       const uint8_t *our_pub_x,
                       const uint8_t *peer_pub_x,
                       uint8_t *out_confirm)
{
    if (!tk || !rand || !out_confirm) {
        return -1;
    }

    // For now, use TK as key and our_rand as 128‑bit CMAC input.
    // This is NOT spec‑correct but at least deterministic.
    uint8_t m[16];
    memcpy(m, rand, 16);

    int ret = ble_sm_alg_aes_cmac(tk, m, sizeof(m), out_confirm);
    if (ret != 0) {
        printf("[SMP-CRYPTO] Failed to compute confirm\n");
        return ret;
    }

    printf("[SMP-CRYPTO] ✓ Computed Pairing Confirm (experimental)\n");
    return 0;
}


// Compute Random value (just use random nonce directly)
int smp_crypto_random(uint8_t *out_random) {
    if (!out_random) return -1;
    
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    
    int ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0);
    if (ret != 0) goto exit;
    
    ret = mbedtls_ctr_drbg_random(&ctr_drbg, out_random, 16);
    
exit:
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    
    return ret;
}


// Validate DHKey check (verify peer's confirm matches our computation)
int smp_crypto_dhkey_check(const uint8_t *peer_rand,    // 16 bytes
                           const uint8_t *our_rand,     // 16 bytes
                           const uint8_t *dhkey,        // 32 bytes
                           const uint8_t *peer_confirm, // 16 bytes (what peer sent)
                           const uint8_t *our_pub_x,    // 32 bytes
                           const uint8_t *peer_pub_x) { // 32 bytes
    
    uint8_t computed_confirm[16];
    
    // Recompute their confirm: F4(vr, ur, X, z)
    int ret = ble_sm_alg_f4(peer_pub_x, our_pub_x, dhkey, 0, computed_confirm);
    if (ret != 0) {
        printf("[SMP-CRYPTO] Failed to compute peer confirm check\n");
        return ret;
    }
    
    // Compare
    if (memcmp(peer_confirm, computed_confirm, 16) == 0) {
        printf("[SMP-CRYPTO] ✓ DHKey check PASSED\n");
        return 0;
    } else {
        printf("[SMP-CRYPTO] ✗ DHKey check FAILED\n");
        return -1;
    }
}

