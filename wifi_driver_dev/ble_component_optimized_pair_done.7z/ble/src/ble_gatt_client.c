// ble_gatt_client.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

// Include your BLE HCI send headers, replace below
extern void send_hci_acl_packet(const uint8_t *data, size_t len);

static uint16_t connection_handle = 0; // to be set on connection established

// ATT Opcodes for discovery
#define ATT_OP_READ_BY_GRP_TYPE_REQ 0x10
#define ATT_OP_READ_BY_GRP_TYPE_RSP 0x11
#define ATT_OP_ERROR_RSP 0x01

// ATT UUID for Primary Service (16-bit UUID)
static const uint8_t primary_service_uuid[2] = {0x00, 0x28}; // 0x2800 little endian

// GATT CID for ATT over L2CAP
#define L2CAP_CID_ATT 0x0004

// Sends an ATT request encapsulated inside L2CAP ACL packet over HCI
void send_att_request(uint16_t conn_handle, const uint8_t* att_data, size_t att_len) {
    if (!att_data || att_len == 0) return;

    // ACL Header fields:
    // Handle (12 bits) | PB (2 bits) | BC (2 bits)
    uint16_t pb_bc = (0x02 << 12); // PB=0x02 (start of automatically flushable data), BC=0
    uint16_t handle_pb_bc = (conn_handle & 0x0FFF) | (pb_bc & 0xF000);

    uint16_t l2cap_len = att_len + 2; // Length of ATT payload + 2 bytes CID
    uint16_t acl_data_total_len = l2cap_len + 4; // L2CAP header(4) + payload

    size_t pkt_len = 1 + 2 + acl_data_total_len; // 1 byte packet type + ACL header(2 bytes) + ACL data

    uint8_t *pkt = malloc(pkt_len);
    if (!pkt) {
        printf("[GATT] Failed to allocate packet buffer\n");
        return;
    }

    size_t pos = 0;
    pkt[pos++] = 0x02; // HCI ACL Data Packet

    // ACL Header: Handle + PB/BC (16 bits)
    pkt[pos++] = (uint8_t)(handle_pb_bc & 0xFF);
    pkt[pos++] = (uint8_t)((handle_pb_bc >> 8) & 0xFF);

    // Data Total Length (16 bits)
    pkt[pos++] = (uint8_t)(acl_data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((acl_data_total_len >> 8) & 0xFF);

    // L2CAP length (16 bits)
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);

    // L2CAP Channel ID (CID) (16 bits)
    pkt[pos++] = (uint8_t)(L2CAP_CID_ATT & 0xFF);
    pkt[pos++] = (uint8_t)((L2CAP_CID_ATT >> 8) & 0xFF);

    // ATT payload
    memcpy(&pkt[pos], att_data, att_len);
    pos += att_len;

    send_hci_acl_packet(pkt, pos);
    free(pkt);

    printf("[GATT] Sent ATT request opcode 0x%02X\n", att_data[0]);
}

// Parses ATT Read By Group Type Response to list discovered services
void parse_att_read_by_group_type_rsp(const uint8_t *data, size_t len) {
    if (!data || len < 1) return;
    // Format:
    // 1 byte opcode (0x11)
    // Rest is sets of: Handle (2 bytes) | End Group Handle (2 bytes) | UUID (2 or 16 bytes)
    printf("[GATT] ATT Read By Group Type Response, length=%d\n", (int)len);

    int offset = 1;
    int value_len = data[1]; // length of each attribute data
    printf("[GATT] Each attribute length = %d\n", value_len);

    while (offset + value_len <= len) {
        uint16_t start_handle = data[offset] | (data[offset + 1] << 8);
        uint16_t end_handle   = data[offset + 2] | (data[offset + 3] << 8);
        uint16_t uuid = 0;
        if (value_len >= 6) {
            uuid = data[offset + 4] | (data[offset + 5] << 8);
        }
        printf("  Service: Start Handle: 0x%04X, End Handle: 0x%04X, UUID: 0x%04X\n",
                start_handle, end_handle, uuid);
        offset += value_len;
    }
}

// Call this function when you receive ACL packets to parse ATT responses (simplified)
void handle_gatt_acl_packet(const uint8_t *data, size_t len) {
    if (!data || len < 11) return; // minimal length check

    // ACL packet structure: Start from Index 5 after L2CAP header
    // Data starts at offset 9 (1 pkt type + 2 ACL header + 2 L2CAP len + 2 CID)
    // So ATT payload start = data[9]
    const uint8_t *att_data = &data[9];
    int att_len = (data[3] | (data[4] << 8)) - 4; // L2CAP length minus CID

    if (att_len < 1) return;

    uint8_t opcode = att_data[0];
    switch (opcode) {
        case ATT_OP_READ_BY_GRP_TYPE_RSP:
            parse_att_read_by_group_type_rsp(att_data, att_len);
            break;
        case ATT_OP_ERROR_RSP:
            printf("[GATT] Received Error Response\n");
            break;
        default:
            printf("[GATT] Received ATT Opcode 0x%02X\n", opcode);
            break;
    }
}

// Start GATT Primary Service Discovery (call this after pairing complete)
void gatt_discover_services(uint16_t conn_handle) {
    connection_handle = conn_handle;
    uint8_t req[7] = {
        ATT_OP_READ_BY_GRP_TYPE_REQ,
        0x01, 0x00,             // Start Handle 0x0001 little endian
        0xFF, 0xFF,             // End Handle 0xFFFF
        primary_service_uuid[0], // UUID LSB
        primary_service_uuid[1]  // UUID MSB
    };
    send_att_request(conn_handle, req, sizeof(req));
}

// Simple keepalive task just prints message every 10 seconds to keep connection alive
static void keepalive_task(void *arg) {
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(10000));
        if (connection_handle == 0) {
            printf("[GATT] Connection closed, deleting keepalive task\n");
            break;
        }
        printf("[GATT] Keepalive: connection active handle 0x%04X\n", connection_handle);
    }
    vTaskDelete(NULL);
}

void gatt_start_keepalive(void) {
    xTaskCreate(keepalive_task, "gatt_keepalive", 2048, NULL, 5, NULL);
}

