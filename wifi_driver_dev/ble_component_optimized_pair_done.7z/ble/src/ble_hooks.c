/*
* BLE Central - Scan, Connect & Just Works Pairing (Direct HCI)
* Scans for "b4b7edc6", connects, and performs Just Works pairing
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "nvs_flash.h"
#include "esp_err.h"
#include "custom_ble.h"
#include "smp_crypto.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"
#include "mbedtls/cmac.h"
#include "mbedtls/aes.h"

#define TARGET_DEVICE_NAME "b4b7edc6"

/* ========== HCI OpCodes & Events ========== */
#define HCI_PACKET_TYPE_CMD 0x01
#define HCI_PACKET_TYPE_EVT 0x04
#define HCI_EVT_CMD_COMPLETE 0x0E
#define HCI_EVT_CMD_STATUS 0x0F
#define HCI_EVT_LE_META 0x3E
#define HCI_LE_EVT_CONN_COMPLETE 0x01
#define HCI_LE_EVT_ADV_REPORT 0x02
#define HCI_LE_EVT_PASSKEY_DISPLAY 0x08
#define HCI_EVT_DISCONNECT_COMPLETE 0x05

#define HCI_OP_LE_SET_SCAN_ENABLE 0x200C
#define HCI_OP_LE_CREATE_CONN 0x200D

/* ========== SMP Pairing State Machine ========== */
typedef enum {
    PAIRING_IDLE,
    PAIRING_REQUEST_SENT,
    PAIRING_RESPONSE_RCVD,
    PAIRING_CONFIRM_SENT,
    PAIRING_RANDOM_EXCHANGED,
    PAIRING_COMPLETE,
    PAIRING_FAILED
} pairing_state_t;

static pairing_state_t pairing_state = PAIRING_IDLE;

/* ========== State & Globals ========== */
static EventGroupHandle_t hci_events = NULL;
#define HCI_EVT_RX_BIT (1 << 0)
#define HCI_CONN_COMPLETE_BIT (1 << 1)

#define MAX_PAIRING_ATTEMPTS 3
static uint8_t pairing_attempts = 0;
static bool target_found = false;
static bool connection_active = false;
static uint8_t target_addr[6];
static uint8_t target_addr_type = 0;
static uint16_t connection_handle = 0;
static volatile uint16_t last_cmd_opcode = 0;
static volatile uint8_t last_cmd_status = 0;
//pair trackers
static bool peer_confirm_received = false;
static uint32_t peer_passkey = 0;
static bool passkey_received = false;
// Add to globals (after existing pairing globals):
// Global ephemeral keys
static ble_sm_ecc_point_t our_ephemeral_pub;
static ble_sm_ecc_secret_t our_ephemeral_priv;

//static uint8_t peer_ephemeral_pub_x[32];
static bool ephemeral_keys_generated = false;
uint8_t local_addr[6] = { 0 }; // device address
uint8_t local_addr_type = 0;   // device address type
static bool local_addr_received = false;
// CHANGE: Set fallback type to 0 and ensure bytes are Little Endian (LSB first)
// If your address is 84:1F:E8:15:AF:32, the array below is correct (LSB at index 0)
static uint8_t fallback_local_addr[6] = {0x32, 0xAF, 0x15, 0xE8, 0x1F, 0x84}; 
static uint8_t fallback_local_addr_type = 0; // CHANGE: Set to 0 (Public)
static uint8_t preq_pdu[7];
static uint8_t pres_pdu[7];
static uint8_t our_addr[6] = {0};
static uint8_t peer_addr[6] = {0};
static uint8_t iat = 0; // Our address type (0=public,1=random)
static uint8_t rat = 1; // Peer address type
static uint8_t peer_public_key[64];
static bool peer_public_key_received = false;
static uint8_t dhkey[32];
static uint8_t peer_confirm[16];
static uint8_t our_random[16];
static uint8_t peer_random[16];
static bool pairing_complete = false;
/* --- BLE SMP stored PDUs & state (for c1 debugging) --- */
static uint8_t stored_preq[7];
static uint8_t stored_pres[7];
static bool stored_preq_valid = false;
static bool stored_pres_valid = false;

/* ========== Helper Functions ========== */
static void send_hci(uint8_t *cmd, uint16_t len) {
    int retry = 50;
    while (!esp_vhci_host_check_send_available() && retry-- > 0)
        vTaskDelay(pdMS_TO_TICKS(1));
    esp_vhci_host_send_packet(cmd, len);
}
void send_read_bd_addr_cmd(void) {
    uint8_t cmd[] = {0x01, 0x09, 0x10, 0x00}; // HCI Read BD_ADDR opcode 0x1009
    send_hci(cmd, sizeof(cmd));
    printf("[HCI] Sent Read BD_ADDR command\n");
}

// Generate secure random for pairing
static int init_pairing_random(void) {
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    
    mbedtls_entropy_init(&entropy);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    
    if (mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0) != 0) {
        return -1;
    }
    
    // Generate 16 random bytes
    if (mbedtls_ctr_drbg_random(&ctr_drbg, our_random, 16) != 0) {
        return -1;
    }
    
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    
    printf("[SMP] Generated secure random for pairing\n");
    printf("[LOG] Our random: ");
    for (int i = 0; i < 16; i++) printf("%02X ", our_random[i]);
    printf("\n");
    
    return 0;
}
/*    const uint8_t smp_payload[] = {
        0x01, // Pairing Request 
        0x03, // IO Capability: NoInputNoOutput 
        0x00, // OOB data: Not present 
        0x01, // AuthReq: Bonding 
        0x10, // MaxEncKeySize = 16 
        0x07, // Initiator Key Dist 
        0x07  // Responder Key Dist 
    };*/
/* ========== Send SMP Pairing Request ========== */
static void send_smp_pairing_request(uint16_t handle) {
    int retry = 100;
    while (!esp_vhci_host_check_send_available() && retry-- > 0) {
        vTaskDelay(pdMS_TO_TICKS(5));
    }
    if (retry <= 0) {
        printf("[SMP] VHCI STILL not ready after 500ms - aborting\n");
        return;
    }

    // IO Cap = NoInputNoOutput (0x03), OOB=0, AuthReq=0 (no MITM, no bonding)
    const uint8_t smp_payload[] = {
        0x01, 0x03, 0x00, 0x00, 0x10, 0x00, 0x00
    };

    // ⭐⭐⭐ STORE PREQ PDU FOR c1()
    memcpy(preq_pdu, smp_payload, 7);

    printf("[DEBUG] Stored PREQ: %02X %02X %02X %02X %02X %02X %02X\n",
           preq_pdu[0], preq_pdu[1], preq_pdu[2],
           preq_pdu[3], preq_pdu[4], preq_pdu[5], preq_pdu[6]);
               
    const uint16_t smp_len = sizeof(smp_payload);
    const uint16_t l2cap_len = smp_len;
    const uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12) | (0x00 << 14);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;

    uint8_t *pkt = (uint8_t *)malloc(pkt_len);
    if (!pkt) {
        printf("[SMP] malloc failed\n");
        return;
    }

    size_t pos = 0;
    pkt[pos++] = 0x02;  // HCI ACL
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], smp_payload, smp_len);
    pos += smp_len;

    printf("[SMP] Sending Pairing Request (No MITM, No Bonding) over L2CAP (handle=0x%04X, pkt_len=%u)\n", handle, (unsigned int)pkt_len);

    send_hci(pkt, pkt_len);
    free(pkt);

    pairing_state = PAIRING_REQUEST_SENT;
    pairing_attempts++;
}

// Function to be called on connection completion, set addresses and types here
// Called on LE Connection Complete to update addresses and pairing state
void on_connection_complete(uint8_t *local_mac, uint8_t local_addr_type,
                            uint8_t *remote_mac, uint8_t remote_addr_type,
                            uint16_t handle) {
    memcpy(our_addr, local_mac, 6);
    iat = local_addr_type;     // Initiator address type
    memcpy(peer_addr, remote_mac, 6);
    rat = remote_addr_type;    // Responder address type
    connection_handle = handle;

    pairing_complete = false;
    pairing_state = PAIRING_IDLE;

    printf("[LOG] Our Addr: %02X:%02X:%02X:%02X:%02X:%02X (type %d)\n",
           our_addr[0], our_addr[1], our_addr[2], our_addr[3], our_addr[4], our_addr[5], iat);
    printf("[LOG] Peer Addr: %02X:%02X:%02X:%02X:%02X:%02X (type %d)\n",
           peer_addr[0], peer_addr[1], peer_addr[2], peer_addr[3], peer_addr[4], peer_addr[5], rat);

    // Initiate SMP pairing request
    send_smp_pairing_request(handle);
}
// Fill buffer with passkey bytes for experimental confirm/random (not cryptographically correct)
static void fill_passkey_bytes(uint8_t *buf, uint32_t passkey, uint8_t smp_code) {
    buf[0] = smp_code;  // SMP code (e.g. 0x03 for confirm, 0x04 for random)
    memset(&buf[1], 0, 16);
    buf[1] = (uint8_t)(passkey & 0xFF);
    buf[2] = (uint8_t)((passkey >> 8) & 0xFF);
    buf[3] = (uint8_t)((passkey >> 16) & 0xFF);
    buf[4] = (uint8_t)((passkey >> 24) & 0xFF);
    printf("[SMP-EXPERIMENTAL] Using passkey %06u for bytes 1-4\n", passkey);
}

static void send_smp_pairing_confirm(uint16_t handle) {
    uint8_t confirm_payload[17];
    confirm_payload[0] = 0x03;

    uint8_t tk[16] = {0};  // Just Works TK, all zeros
	printf("[LOG] Pairing Request PDU: ");
	for (int i=0; i<7; i++) printf("%02X ", preq_pdu[i]);
	printf("\n");

	printf("[LOG] Pairing Response PDU: ");
	for (int i=0; i<7; i++) printf("%02X ", pres_pdu[i]);
	printf("\n");

	printf("[LOG] Our random: ");
	for (int i=0; i<16; i++) printf("%02X ", our_random[i]);
	printf("\n");
    printf("[LOG] Our Address: ");
    for (int i=0; i<6; i++) printf("%02X ", our_addr[i]);
    printf(" (type=%d)\n", iat);
    
    printf("[LOG] Peer Address: ");
    for (int i=0; i<6; i++) printf("%02X ", peer_addr[i]);
    printf(" (type=%d)\n", rat);
    
    printf("[LOG] Address types: iat=%d, rat=%d\n", iat, rat);
	// CHANGE: Use a local aligned buffer for the c1 output
    uint8_t local_confirm[16];    	
    int rc = ble_sm_alg_c1(tk, our_random, preq_pdu, pres_pdu, iat, rat,
                           our_addr, peer_addr, local_confirm);
    if (rc != 0) {
        printf("[SMP] SMP c1 confirm calculation failed\n");
        return;
    }
	// Copy the result into the payload
    memcpy(&confirm_payload[1], local_confirm, 16);    
    printf("[LOG] Computed Confirm: ");
    for (int i = 0; i < 16; i++) printf("%02X ", confirm_payload[1 + i]);
    printf("\n");
    printf("[SMP] SMP c1 Pairing Confirm computed\n");

    // Send confirm payload over ACL/L2CAP as usual
    const uint16_t smp_len = 17;
    const uint16_t l2cap_len = smp_len;
    const uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;

    uint8_t *pkt = malloc(pkt_len);
    if (!pkt) {
        printf("[SMP-CRYPTO] malloc failed\n");
        return;
    }

    size_t pos = 0;
    pkt[pos++] = 0x02;
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], confirm_payload, smp_len);

    printf("[SMP-CRYPTO] Sending Pairing Confirm with SMP c1 value\n");
    send_hci(pkt, pkt_len);
    free(pkt);

    pairing_state = PAIRING_CONFIRM_SENT;
}

static void send_smp_pairing_random(uint16_t handle) {
    uint8_t random_payload[17];
    random_payload[0] = 0x04;
    memcpy(&random_payload[1], our_random, 16);
    
    printf("[SMP-CRYPTO] Sending Pairing Random\n");
	printf("[LOG] Our random: ");
	for (int i=0; i<16; i++) printf("%02X ", our_random[i]);
	printf("\n");    
    
    // Send ACL/L2CAP packet
    const uint16_t smp_len = 17;
    const uint16_t l2cap_len = smp_len;
    const uint16_t cid = 0x0006;
    uint16_t pb_bc = (0x02 << 12);
    uint16_t acl_handle_field = (handle & 0x0FFF) | (pb_bc & 0xF000);
    uint16_t data_total_len = 4 + l2cap_len;
    size_t pkt_len = 1 + 2 + 2 + 4 + smp_len;
    
    uint8_t *pkt = malloc(pkt_len);
    if (!pkt) {
        printf("[SMP-CRYPTO] malloc failed\n");
        return;
    }
    
    size_t pos = 0;
    pkt[pos++] = 0x02;
    pkt[pos++] = (uint8_t)(acl_handle_field & 0xFF);
    pkt[pos++] = (uint8_t)((acl_handle_field >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(data_total_len & 0xFF);
    pkt[pos++] = (uint8_t)((data_total_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(l2cap_len & 0xFF);
    pkt[pos++] = (uint8_t)((l2cap_len >> 8) & 0xFF);
    pkt[pos++] = (uint8_t)(cid & 0xFF);
    pkt[pos++] = (uint8_t)((cid >> 8) & 0xFF);
    memcpy(&pkt[pos], random_payload, smp_len);
    
    send_hci(pkt, pkt_len);
    free(pkt);
    
    pairing_state = PAIRING_RANDOM_EXCHANGED;
}


/* ========== SMP Pairing State Machine Handler ========== */
// SMP packet handler additions/modifications:

// SMP packet handler: process SMP messages from ACL
static void handle_smp_packet(const uint8_t *smp, uint16_t smp_len, uint16_t handle) {
    static uint8_t expected_confirm[16];
    static uint8_t tk[16] = {0}; // Just Works TK, all zeros

    uint8_t smp_code = smp[0];
    printf("[SMP_STATE] Received SMP code 0x%02X\n", smp_code);

    switch (smp_code) {
        case 0x01: // Pairing Request
            if (smp_len >= 7) {
                //memcpy(preq_pdu, smp, 7);
                printf("[LOG] Pairing Request PDU from peripheral: ");
                for (int i = 0; i < 7; i++) printf("%02X ", preq_pdu[i]);
                printf("\n");
            }
            break;

        case 0x02: // Pairing Response
            if (smp_len >= 7) {
                memcpy(pres_pdu, smp, 7);
                printf("[LOG] Pairing Response PDU: ");
                for (int i = 0; i < 7; i++) printf("%02X ", pres_pdu[i]);
                printf("\n");
                pairing_state = PAIRING_RESPONSE_RCVD;
				if (init_pairing_random() != 0) {
				    printf("[SMP] Failed to generate random!\n");
				    return;
				}                
                printf("[SMP] Sending Pairing Confirm...\n");
                send_smp_pairing_confirm(handle);
            }
            break;

        case 0x03: // Pairing Confirm
            if (smp_len >= 17) {
                memcpy(peer_confirm, &smp[1], 16);
                printf("[LOG] Peer Pairing Confirm: ");
                for (int i = 0; i < 16; i++) printf("%02X ", peer_confirm[i]);
                printf("\n");
                pairing_state = PAIRING_CONFIRM_SENT;
                printf("[SMP] Sending OUR Pairing Random...\n");
                send_smp_pairing_random(handle);
            }
            break;

        case 0x04: // Pairing Random
            if (smp_len >= 17) {
                memcpy(peer_random, &smp[1], 16);
                printf("[LOG] Peer Pairing Random: ");
                for (int i = 0; i < 16; i++) printf("%02X ", peer_random[i]);
                printf("\n");

				int rc = ble_sm_alg_c1(
						tk,
						peer_random,  // r = peer's random
						preq_pdu,     // PREQ (7 bytes) - initiator request
						pres_pdu,     // PRES (7 bytes) - responder response
						iat,          // initiator address type
						rat,          // responder address type
						our_addr,     // IA (we are initiator)
						peer_addr,    // RA (responder)
						expected_confirm  // output 16-byte buffer
				);

                if (rc != 0) {
                    printf("[SMP-CRYPTO] ble_sm_alg_c1() failed with %d\n", rc);
                    pairing_state = PAIRING_FAILED;
                    return;
                }

                printf("[LOG] Expected Confirm: ");
                for (int i = 0; i < 16; i++) printf("%02X ", expected_confirm[i]);
                printf("\n");
				printf("[LOG] Peer's Confirm:                    ");
				for (int i = 0; i < 16; i++) printf("%02X ", peer_confirm[i]);
				printf("\n");
                if (memcmp(peer_confirm, expected_confirm, 16) != 0) {
                    printf("[SMP] Peer Confirm validation FAILED\n");
                    pairing_state = PAIRING_FAILED;
                    return;
                }

                printf("[SMP] Pairing confirm validated successfully, pairing complete\n");
                pairing_complete = true;
                pairing_state = PAIRING_COMPLETE;
            }
            break;

        case 0x0C: // SMP Public Key
            if (smp_len >= 65) {
                memcpy(peer_public_key, &smp[1], 64);
                peer_public_key_received = true;
                printf("[LOG] Peer Public Key: ");
                for (int i = 0; i < 64; i++) printf("%02X ", peer_public_key[i]);
                printf("\n");

                int rc = ble_sm_alg_gen_dhkey(peer_public_key, &peer_public_key[32],
                                             our_ephemeral_priv.data, dhkey);
                if (rc != 0) {
                    printf("[SMP-CRYPTO] DHKey generation failed\n");
                    pairing_state = PAIRING_FAILED;
                    return;
                }

                printf("[LOG] DHKey: ");
                for (int i = 0; i < 32; i++) printf("%02X ", dhkey[i]);
                printf("\n");
            }
            break;

        case 0x05: // Pairing Failed
            printf("[SMP] Pairing Failed with reason 0x%02X\n", smp[1]);
            pairing_state = PAIRING_FAILED;
            break;

        default:
            printf("[SMP] Unknown SMP code 0x%02X\n", smp_code);
            break;
    }
}
/* ========== ACL/L2CAP SMP Handler ========== */
static void handle_acl_packet_and_log_smp(const uint8_t *data, uint16_t len) {
    if (len < 5) {
        printf("[ACL] Packet too short (len=%u)\n", len);
        return;
    }
    
    printf("[ACL_RX] Received ACL packet, len=%u bytes\n", len);
    
    uint16_t handle_field = (uint16_t)data[1] | ((uint16_t)data[2] << 8);
    uint16_t handle = handle_field & 0x0FFF;
    uint16_t data_total_len = (uint16_t)data[3] | ((uint16_t)data[4] << 8);
    
    if (len < 1 + 2 + 2) return;
    size_t offset = 1 + 2 + 2; /* start of L2CAP data */
    
    if ((size_t)len < offset + 4) return;
    
    uint16_t l2cap_len = (uint16_t)data[offset] | ((uint16_t)data[offset+1] << 8);
    uint16_t l2cap_cid = (uint16_t)data[offset+2] | ((uint16_t)data[offset+3] << 8);
    offset += 4;
    
    printf("[ACL] handle=0x%04X total_len=%u L2CAP_len=%u CID=0x%04X\n", 
           handle, data_total_len, l2cap_len, l2cap_cid);
    
    if (l2cap_cid == 0x0006 && connection_handle == handle) { /* SMP over correct handle */
        if (l2cap_len == 0 || (size_t)l2cap_len > (len - offset)) {
            printf("[SMP] truncated or invalid l2cap length\n");
            return;
        }
        
        const uint8_t *smp = &data[offset];
        uint8_t smp_code = smp[0];
        
        printf("[SMP] code=0x%02X (%s) len=%u\n", smp_code,
            (smp_code == 0x01) ? "Pairing Request" :
            (smp_code == 0x02) ? "Pairing Response" :
            (smp_code == 0x03) ? "Pairing Confirm" :
            (smp_code == 0x04) ? "Pairing Random" :
            (smp_code == 0x05) ? "Pairing Failed" : "UNKNOWN",
            l2cap_len);
        
        printf("[SMP] bytes: ");
        for (int i = 0; i < (int)l2cap_len && i < 16; i++) printf("%02X ", smp[i]);
        printf("\n");
        
        // Process SMP state machine
        handle_smp_packet(smp, l2cap_len, handle);
    }
}

/* ========== Improved Watchdog ========== */
static void pairing_watchdog(void *arg) {
    const int max_retries = 10; // Increased timeout
    int timeout_count = 0;
    
    for (int retry = 0; retry < max_retries; retry++) {
        vTaskDelay(pdMS_TO_TICKS(2000)); // 2s intervals
        
        if (!connection_active) {
            printf("[WATCHDOG] Connection lost, exiting\n");
            break;
        }
        
        if (pairing_complete || pairing_state >= PAIRING_COMPLETE) {
            printf("[WATCHDOG] ✓ Pairing complete! Exiting\n");
            break;
        }
        
		if (pairing_state >= PAIRING_RANDOM_EXCHANGED) {
			printf("[WATCHDOG] ✓ Random exchanged! Exiting\n");
			break;
		}
        
        if (pairing_state == PAIRING_FAILED) {
            printf("[WATCHDOG] Pairing failed state detected\n");
            break;
        }
        
        timeout_count++;
        printf("[WATCHDOG] Timeout #%d/%d (state=%d)\n", timeout_count, max_retries, pairing_state);
        
        if (timeout_count >= max_retries) {
            printf("[WATCHDOG] Final timeout - pairing failed\n");
            break;
        }
    }
    vTaskDelete(NULL);
}
static bool wait_for_cmd_complete_opcode(uint16_t opcode, TickType_t timeout_ms) {
    TickType_t end = xTaskGetTickCount() + pdMS_TO_TICKS(timeout_ms);
    while (xTaskGetTickCount() < end) {
        EventBits_t bits = xEventGroupWaitBits(hci_events, HCI_EVT_RX_BIT, pdTRUE, pdFALSE, pdMS_TO_TICKS(50));
        if (bits & HCI_EVT_RX_BIT) {
            if (last_cmd_opcode == opcode) return true;
        }
    }
    return false;
}

/* ========== Connect Command ========== */
static void send_create_connection(void) {
    printf("[CONNECT] Initiating connection to %02x:%02x:%02x:%02x:%02x:%02x\n",
           target_addr[5], target_addr[4], target_addr[3],
           target_addr[2], target_addr[1], target_addr[0]);
    
    uint8_t cmd_conn[] = {
        HCI_PACKET_TYPE_CMD,
        (HCI_OP_LE_CREATE_CONN & 0xFF), (uint8_t)(HCI_OP_LE_CREATE_CONN >> 8),
        0x19, /* Param Len */
        0x60, 0x00, 0x30, 0x00, 0x00, target_addr_type,
        target_addr[0], target_addr[1], target_addr[2], target_addr[3], target_addr[4], target_addr[5],
        0x00, // <--- This byte is Own_Addr_Type. 0x00 = Public.
        0x18, 0x00, 0x28, 0x00, 0x00, 0x00, 0xF4, 0x01, 0x00, 0x00, 0x00, 0x00
    };
    send_hci(cmd_conn, sizeof(cmd_conn));
}

/* ========== Debug Print ========== */
static void debug_print_hci_event(uint8_t *data, uint16_t len) {
    if (!data || len < 3) return;
    uint8_t evt_code = data[1];
    uint8_t evt_len = data[2];
    printf("[HCI_EVT] Type: 0x%02X, Code: 0x%02X, Len: %d, Data: ", data[0], evt_code, evt_len);
    for (int i = 0; i < len && i < 48; i++) printf("%02X ", data[i]);
    if (len > 48) printf("...");
    printf("\n");
    
    if (evt_code == HCI_EVT_LE_META && len >= 4) {
        uint8_t sub_evt = data[3];
        printf(" [LE_META] SubEvent: 0x%02X", sub_evt);
        switch (sub_evt) {
            case 0x01: printf(" (LE_CONN_COMPLETE)\n"); break;
            case 0x02: printf(" (LE_ADV_REPORT)\n"); break;
            case 0x08: printf(" (LE_PASSKEY_DISPLAY)\n"); break;
            default: printf(" (UNKNOWN)\n"); break;
        }
    }
}
static void connection_task(void *arg) {
    const uint16_t expected_opcode = HCI_OP_LE_SET_SCAN_ENABLE;
    const TickType_t timeout_ms = 500;
    
    printf("[CONNECT_TASK] Waiting for Stop-Scan (opcode 0x%04X) completion\n", expected_opcode);
    
    bool ok = wait_for_cmd_complete_opcode(expected_opcode, timeout_ms);
    if (!ok) {
        printf("[CONNECT_TASK] Stop-scan timeout, proceeding anyway\n");
    }
    
    vTaskDelay(pdMS_TO_TICKS(50));
    send_create_connection();
    vTaskDelay(pdMS_TO_TICKS(10));
    vTaskDelete(NULL);
}
/* ========== VHCI Handler ========== */
static int vhci_recv_handler(uint8_t *data, uint16_t len) {
    if (!data || len < 3) return 0;
    
    // Handle ACL data first
    if (data[0] == 0x02) {
        handle_acl_packet_and_log_smp(data, len);
        return 0;
    }
    
    if (data[0] != HCI_PACKET_TYPE_EVT) return 0;
    
    debug_print_hci_event(data, len);
    uint8_t evt_code = data[1];
     if (evt_code == 0x0E) { // Command Complete Event
        uint16_t opcode = data[4] | (data[5] << 8);

        if (opcode == 0x1009 && len >= 13) { // Read BD_ADDR command complete
            // The BD_ADDR starts at byte 7 of the event packet (Status is byte 6)
            // We copy 6 bytes directly to preserve Little-Endian order
			memcpy(local_addr, &data[7], 6);
            local_addr_received = true;

            printf("[HCI] Local BD_ADDR received: %02X:%02X:%02X:%02X:%02X:%02X\n",
                   local_addr[0], local_addr[1], local_addr[2],
                   local_addr[3], local_addr[4], local_addr[5]);
        }
    }   
    // LE Meta Events
    if (evt_code == HCI_EVT_LE_META) {
        uint8_t sub_evt = data[3];
        
        // Advertising Report
        if (sub_evt == HCI_LE_EVT_ADV_REPORT && !target_found) {
            uint8_t *p = &data[5];
            uint8_t addr_type = p[1];
            uint8_t *addr = &p[2];
            uint8_t data_len = p[8];
            uint8_t *adv_data = &p[9];
            
            int pos = 0;
            while (pos < data_len) {
                uint8_t ad_len = adv_data[pos];
                if (ad_len == 0 || pos + 1 + ad_len > data_len) break;
                uint8_t ad_type = adv_data[pos + 1];
                uint8_t val_len = ad_len - 1;
                uint8_t *val = &adv_data[pos + 2];
                
                if ((ad_type == 0x09 || ad_type == 0x08) && val_len == strlen(TARGET_DEVICE_NAME)) {
                    if (memcmp(val, TARGET_DEVICE_NAME, val_len) == 0) {
                        printf("\n[SCAN] *** FOUND TARGET: %s ***\n", TARGET_DEVICE_NAME);
                        memcpy(target_addr, addr, 6);
                        target_addr_type = addr_type;
                        target_found = true;
                        
                        uint8_t stop_scan[] = { HCI_PACKET_TYPE_CMD, 0x0C, 0x20, 0x02, 0x00, 0x00 };
                        send_hci(stop_scan, sizeof(stop_scan));
                        
                        xTaskCreate(connection_task, "connect_task", 4096, NULL, 10, NULL);
                        return 0;
                    }
                }
                pos += 1 + ad_len;
            }
        }
        
        // Connection Complete
        else if (sub_evt == HCI_LE_EVT_CONN_COMPLETE) {
            if (len >= 7) {
                uint8_t status = data[4];
                uint16_t handle = data[5] | (data[6] << 8);
                
                if (status == 0) {
                    printf("\n[CONNECT] *** CONNECTED SUCCESSFULLY! *** (Handle: 0x%04X)\n", handle);
                    connection_handle = handle;
                    connection_active = true;
                    pairing_complete = false;
                    pairing_state = PAIRING_IDLE;

				    // Use cached peer address from scan
				    uint8_t *remote_mac = target_addr;
				    uint8_t remote_addr_type = target_addr_type;                    
                    printf("[CONNECT] Controller ready. Waiting for SMP pairing...\n");
                    
                    vTaskDelay(pdMS_TO_TICKS(100));
                    printf("[PAIRING] Sending SMP Pairing Request via ACL/L2CAP...\n");
					if (local_addr_received) {
						on_connection_complete(local_addr, local_addr_type, target_addr, target_addr_type, connection_handle);
					} else {
						printf("[ERROR] Local BD_ADDR not received yet - using fallback static address\n");
						on_connection_complete(fallback_local_addr, fallback_local_addr_type, target_addr, target_addr_type, connection_handle);
					}
                    
                    xTaskCreate(pairing_watchdog, "ble_watchdog", 4096, NULL, 5, NULL);
                }
            }
            return 0;
        }
    }
    
    // Disconnect Complete
    else if (evt_code == HCI_EVT_DISCONNECT_COMPLETE) {
        if (len >= 7) {
            uint8_t status = data[3];
            uint16_t handle = data[4] | (data[5] << 8);
            uint8_t reason = data[6];
            printf("[DISCONNECT] status=0x%02X handle=0x%04X reason=0x%02X (state=%d)\n", 
                   status, handle, reason, pairing_state);
            
            if (connection_active && handle == connection_handle) {
                connection_active = false;
                connection_handle = 0;
                pairing_state = PAIRING_IDLE;
            }
        }
    }
    
    // Command Complete/Status
    else if (evt_code == HCI_EVT_CMD_COMPLETE || evt_code == HCI_EVT_CMD_STATUS) {
        uint16_t opcode = 0;
        uint8_t status = 0;
        if (evt_code == HCI_EVT_CMD_COMPLETE && len >= 7) {
            opcode = data[4] | (data[5] << 8);
            status = data[6];
        } else if (evt_code == HCI_EVT_CMD_STATUS && len >= 7) {
            status = data[3];
            opcode = data[5] | (data[6] << 8);
        }
        
        last_cmd_opcode = opcode;
        last_cmd_status = status;
        printf("[HCI] CMD_%s: status=0x%02X opcode=0x%04X\n",
               evt_code == HCI_EVT_CMD_COMPLETE ? "COMPLETE" : "STATUS", status, opcode);
        
        if (hci_events) xEventGroupSetBits(hci_events, HCI_EVT_RX_BIT);
    }
    
    return 0;
}

static void vhci_send_avail_handler(void) {}
static const esp_vhci_host_callback_t vhci_cbs = {
    .notify_host_recv = vhci_recv_handler,
    .notify_host_send_available = vhci_send_avail_handler
};

static void start_process(void) {
    printf("[INIT] Starting BLE HCI process...\n");
    
    uint8_t cmd_reset[] = { 0x01, 0x03, 0x0C, 0x00 };
    send_hci(cmd_reset, sizeof(cmd_reset));
    
    vTaskDelay(pdMS_TO_TICKS(200)); 
    send_read_bd_addr_cmd();
    vTaskDelay(pdMS_TO_TICKS(200)); 
    
    uint8_t cmd_evt_mask[] = { 0x01, 0x01, 0x0C, 0x08, 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
    send_hci(cmd_evt_mask, sizeof(cmd_evt_mask));
    
    uint8_t cmd_le_evt_mask[] = { 0x01, 0x01, 0x20, 0x08, 0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };
    send_hci(cmd_le_evt_mask, sizeof(cmd_le_evt_mask));
    
    uint8_t cmd_scan_params[] = { 0x01, 0x0B, 0x20, 0x07, 0x01, 0x60, 0x00, 0x60, 0x00, 0x00, 0x00 };
    send_hci(cmd_scan_params, sizeof(cmd_scan_params));
    
    printf("[SCAN] Starting scan for '%s'...\n", TARGET_DEVICE_NAME);
    uint8_t cmd_scan_enable[] = { 0x01, 0x0C, 0x20, 0x02, 0x01, 0x00 };
    send_hci(cmd_scan_enable, sizeof(cmd_scan_enable));
}

static void main_task(void *arg) {
    while (1) vTaskDelay(pdMS_TO_TICKS(10000));
}

void ble_main(void) {
    nvs_flash_init();
    esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT);
    esp_bt_controller_config_t cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    esp_bt_controller_init(&cfg);
    esp_bt_controller_enable(ESP_BT_MODE_BLE);
    
    hci_events = xEventGroupCreate();
    esp_vhci_host_register_callback(&vhci_cbs);
    
    start_process();
    xTaskCreate(main_task, "main", 4096, NULL, 5, NULL);
    printf("ble main end\n");
}
